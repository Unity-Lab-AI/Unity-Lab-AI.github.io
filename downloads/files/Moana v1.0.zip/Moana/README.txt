================================================================================
                              MOANA MINER v1.0
                         RavenCoin (RVN) KawPow Miner
================================================================================

                            Unity AI Lab
                        www.unityailab.com
                Crew: Hackall360 | Sponge | Gfourteen

================================================================================
                              QUICK START
================================================================================

1. Make sure Python 3.8+ is installed (python.org/downloads)
   - IMPORTANT: Check "Add Python to PATH" during installation

2. Double-click Moana.bat (in the bin folder) or use the Moana shortcut

3. Your browser will open to http://127.0.0.1:4068

4. Enter your RavenCoin wallet address in the dashboard

5. Click "Start Mining" and watch your hashrate!

================================================================================
                            WHAT'S INCLUDED
================================================================================

This download includes everything you need:

  bin/
  ├── Moana.bat           - Main launcher (run this!)
  ├── dashboard.py        - Web dashboard server
  ├── config.bat          - Configuration reference
  ├── miner/
  │   ├── t-rex.exe       - T-Rex Miner (stable, all GPUs)
  │   └── rigel.exe       - Rigel Miner (RTX optimized)
  └── [other support files]

================================================================================
                          SYSTEM REQUIREMENTS
================================================================================

- Windows 10/11 (64-bit)
- Python 3.8 or higher
- NVIDIA GPU with CUDA support (GTX 1060 or better recommended)
- 4GB+ GPU VRAM (6GB+ recommended for KawPow)
- Stable internet connection

================================================================================
                           DASHBOARD FEATURES
================================================================================

- Real-time hashrate monitoring
- Shares accepted/rejected counter
- GPU temperature, power, and fan speed
- Live RavenCoin price from CoinGecko
- Pool and Solo mining modes
- Switch between T-Rex and Rigel miners
- All-time earnings tracking
- One-click start/stop mining

================================================================================
                              MINING POOLS
================================================================================

Default pool: 2Miners (stratum+tcp://rvn.2miners.com:6060)

Other supported pools:
- 2Miners Solo: stratum+tcp://solo-rvn.2miners.com:6060
- Flypool: stratum+ssl://stratum-ravencoin.flypool.org:3443
- Nanopool: stratum+tcp://rvn-us-east1.nanopool.org:12222
- HeroMiners: stratum+tcp://ravencoin.herominers.com:1140

================================================================================
                             CONFIGURATION
================================================================================

All settings are configured through the web dashboard at http://127.0.0.1:4068

Settings are saved to: bin/moana_config.json
Stats are saved to: bin/moana_stats.json

================================================================================
                            TROUBLESHOOTING
================================================================================

"Python not found"
  - Install Python from python.org
  - Make sure "Add Python to PATH" was checked during install
  - Restart your computer after installing

Dashboard won't open
  - Manually go to http://127.0.0.1:4068 in your browser
  - Check if port 4068 is blocked by firewall

Antivirus blocks/deletes miner
  - Mining software triggers false positives
  - Add the Moana folder to your antivirus exclusions
  - For Windows Defender: Settings > Virus & threat protection >
    Manage settings > Exclusions > Add folder

Low hashrate
  - Update NVIDIA drivers to latest version
  - Check GPU temperature (should be below 80C)
  - Try running as Administrator

================================================================================
                               GET HELP
================================================================================

Discord: https://discord.gg/64Rvr5pZas
Website: https://www.unityailab.com
GitHub: https://github.com/Unity-Lab-AI

================================================================================
                              DISCLAIMER
================================================================================

This software is provided "as-is" without warranty. Cryptocurrency mining
involves risks including hardware wear and electricity costs. Users are
responsible for complying with local laws and regulations. Unity AI Lab is
not responsible for any damages or losses resulting from use of this software.

Mining puts your GPU under sustained load. Monitor temperatures and ensure
adequate cooling. Consider undervolting for efficiency and longevity.

================================================================================
                        Thank you for using Moana!
                           Happy Mining!
================================================================================
