================================================================================
                              MOANA MINER v1.0
                         RavenCoin (RVN) KawPow Miner
================================================================================

                            Unity AI Lab
                        www.unityailab.com
                Crew: Hackall360 | Sponge | Gfourteen

          GitHub: https://github.com/Unity-Lab-AI/Moana

================================================================================
                              QUICK START
================================================================================

1. Install Python 3.8+ from python.org/downloads
   - IMPORTANT: Check "Add Python to PATH" during installation

2. Download a miner (T-Rex or Rigel) - see MINER DOWNLOADS below

3. Place the miner .exe in the bin/miner/ folder

4. Double-click Moana.bat (in the bin folder) or use the Moana shortcut

5. Your browser will open to http://127.0.0.1:4068

6. Enter your RavenCoin wallet address in the dashboard

7. Click "Start Mining" and watch your hashrate!

================================================================================
                            MINER DOWNLOADS
================================================================================

You MUST download one of these miners and place it in bin/miner/:

T-REX MINER (Recommended - stable, works on all NVIDIA GPUs)
  GitHub:   https://github.com/trexminer/T-Rex
  Download: https://github.com/trexminer/T-Rex/releases
  Get the Windows CUDA version (e.g., t-rex-0.26.8-win.zip)
  Extract and copy t-rex.exe to bin/miner/

RIGEL MINER (RTX Optimized - better for RTX 30/40 series)
  GitHub:   https://github.com/rigelminer/rigel
  Download: https://github.com/rigelminer/rigel/releases
  Get the Windows version (e.g., rigel-1.x.x-win.zip)
  Extract and copy rigel.exe to bin/miner/

NOTE: Mining software may trigger antivirus false positives.
      Add an exception for the Moana folder if needed.

================================================================================
                            FOLDER STRUCTURE
================================================================================

  Moana/
  ├── README.txt            - This file
  ├── Moana.lnk             - Desktop shortcut
  └── bin/
      ├── Moana.bat         - Main launcher (run this!)
      ├── dashboard.py      - Web dashboard server
      ├── config.bat        - Configuration reference
      ├── moana_config.json - Settings (auto-created)
      ├── moana_stats.json  - Stats (auto-created)
      └── miner/            - PUT YOUR MINER HERE!
          └── (t-rex.exe or rigel.exe)

================================================================================
                          SYSTEM REQUIREMENTS
================================================================================

- Windows 10/11 (64-bit)
- Python 3.8 or higher
- NVIDIA GPU with CUDA support (GTX 1060 or better recommended)
- 4GB+ GPU VRAM (6GB+ recommended for KawPow)
- Stable internet connection

================================================================================
                           DASHBOARD FEATURES
================================================================================

- Real-time hashrate monitoring
- Shares accepted/rejected counter
- GPU temperature, power, and fan speed
- Live RavenCoin price from CoinGecko
- Pool and Solo mining modes
- Switch between T-Rex and Rigel miners
- All-time earnings tracking
- One-click start/stop mining
- Unity AI voice commentary

================================================================================
                              MINING POOLS
================================================================================

Default pool: 2Miners (stratum+tcp://rvn.2miners.com:6060)

Other supported pools:
- 2Miners Solo: stratum+tcp://solo-rvn.2miners.com:6060
- Flypool: stratum+ssl://stratum-ravencoin.flypool.org:3443
- Nanopool: stratum+tcp://rvn-us-east1.nanopool.org:12222
- HeroMiners: stratum+tcp://ravencoin.herominers.com:1140

================================================================================
                             CONFIGURATION
================================================================================

All settings are configured through the web dashboard at http://127.0.0.1:4068

Settings are saved to: bin/moana_config.json
Stats are saved to: bin/moana_stats.json

================================================================================
                            TROUBLESHOOTING
================================================================================

"Python not found"
  - Install Python from python.org
  - Make sure "Add Python to PATH" was checked during install
  - Restart your computer after installing

"Miner not found"
  - Download T-Rex or Rigel from the links above
  - Place the .exe file in the bin/miner/ folder
  - Make sure it's named exactly t-rex.exe or rigel.exe

Dashboard won't open
  - Manually go to http://127.0.0.1:4068 in your browser
  - Check if port 4068 is blocked by firewall

Antivirus blocks/deletes miner
  - Mining software triggers false positives
  - Add the Moana folder to your antivirus exclusions
  - For Windows Defender: Settings > Virus & threat protection >
    Manage settings > Exclusions > Add folder

Low hashrate
  - Update NVIDIA drivers to latest version
  - Check GPU temperature (should be below 80C)
  - Try running as Administrator

================================================================================
                               GET HELP
================================================================================

GitHub:  https://github.com/Unity-Lab-AI/Moana
Discord: https://discord.gg/64Rvr5pZas
Website: https://www.unityailab.com

================================================================================
                              DISCLAIMER
================================================================================

This software is provided "as-is" without warranty. Cryptocurrency mining
involves risks including hardware wear and electricity costs. Users are
responsible for complying with local laws and regulations. Unity AI Lab is
not responsible for any damages or losses resulting from use of this software.

Mining puts your GPU under sustained load. Monitor temperatures and ensure
adequate cooling. Consider undervolting for efficiency and longevity.

================================================================================
                        Thank you for using Moana!
                           Happy Mining!
================================================================================
