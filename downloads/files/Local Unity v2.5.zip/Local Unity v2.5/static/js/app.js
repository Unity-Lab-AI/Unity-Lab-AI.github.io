        // ==================== UTILITIES ====================
        // Get API URL - handles different server configurations
        function getApiUrl(path) {
            // Use current origin for API calls
            return window.location.origin + path;
        }

        // UUID generator - uses crypto.randomUUID if available, fallback for older browsers
        function generateUUID() {
            if (typeof crypto !== 'undefined' && crypto.randomUUID) {
                return crypto.randomUUID();
            }
            // Fallback for older browsers
            return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
                const r = Math.random() * 16 | 0;
                const v = c === 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
        }

        // ==================== INDEXEDDB STORAGE ====================
        // IndexedDB for large data (avatars, images) - better than localStorage
        const DB_NAME = 'UnityAILab';
        const DB_VERSION = 1;
        let db = null;

        function openDatabase() {
            return new Promise((resolve, reject) => {
                if (db) {
                    resolve(db);
                    return;
                }
                const request = indexedDB.open(DB_NAME, DB_VERSION);
                request.onerror = () => reject(request.error);
                request.onsuccess = () => {
                    db = request.result;
                    resolve(db);
                };
                request.onupgradeneeded = (event) => {
                    const database = event.target.result;
                    // store for large blobs like avatars
                    if (!database.objectStoreNames.contains('blobs')) {
                        database.createObjectStore('blobs', { keyPath: 'key' });
                    }
                };
            });
        }

        async function saveToIndexedDB(key, value) {
            try {
                const database = await openDatabase();
                return new Promise((resolve, reject) => {
                    const tx = database.transaction('blobs', 'readwrite');
                    const store = tx.objectStore('blobs');
                    store.put({ key, value, timestamp: Date.now() });
                    tx.oncomplete = () => resolve(true);
                    tx.onerror = () => reject(tx.error);
                });
            } catch (e) {
                console.warn('IndexedDB save failed:', e);
                return false;
            }
        }

        async function loadFromIndexedDB(key) {
            try {
                const database = await openDatabase();
                return new Promise((resolve, reject) => {
                    const tx = database.transaction('blobs', 'readonly');
                    const store = tx.objectStore('blobs');
                    const request = store.get(key);
                    request.onsuccess = () => resolve(request.result?.value || null);
                    request.onerror = () => reject(request.error);
                });
            } catch (e) {
                console.warn('IndexedDB load failed:', e);
                return null;
            }
        }

        async function deleteFromIndexedDB(key) {
            try {
                const database = await openDatabase();
                return new Promise((resolve, reject) => {
                    const tx = database.transaction('blobs', 'readwrite');
                    const store = tx.objectStore('blobs');
                    store.delete(key);
                    tx.oncomplete = () => resolve(true);
                    tx.onerror = () => reject(tx.error);
                });
            } catch (e) {
                console.warn('IndexedDB delete failed:', e);
                return false;
            }
        }

        async function clearIndexedDB() {
            try {
                const database = await openDatabase();
                return new Promise((resolve, reject) => {
                    const tx = database.transaction('blobs', 'readwrite');
                    const store = tx.objectStore('blobs');
                    store.clear();
                    tx.oncomplete = () => resolve(true);
                    tx.onerror = () => reject(tx.error);
                });
            } catch (e) {
                console.warn('IndexedDB clear failed:', e);
                return false;
            }
        }

        // ==================== CONSTANTS ====================
        const CONFIG = {
            API_TIMEOUT: 120000,         // 2 min - image gen can be slow
            POLL_INTERVAL_ONLINE: 30000, // 30s when server is up
            POLL_INTERVAL_OFFLINE: 60000,// 60s when server is down
            MAX_MEMORY_LENGTH: 5000,     // character limit for memory text
            MAX_LOG_ENTRIES: 200,        // prevent DOM bloat in console
            MAX_TEXTAREA_HEIGHT: 200,    // px - input field max height
            DEFAULT_MAX_TOKENS: 2048,    // default response length
            MAX_TOKENS_CEILING: 32768,   // absolute max tokens
            MIN_IMAGE_SIZE: 64,          // minimum image dimension
            MAX_IMAGE_SIZE: 2048,        // maximum image dimension
            LARGE_SESSION_THRESHOLD: 20  // show loading indicator above this
        };

        // ==================== STATE ====================
        const state = {
            isProcessing: false,
            currentSession: null,
            sessions: [],
            trashedSessions: [],  // sessions moved to trash, can be recovered
            memoryText: '',  // Simple text string for memories
            availableModels: [],
            currentModel: null,
            ttsEnabled: false,
            aiAvatar: null,
            avatarGenerationPending: false,
            firstMessageSent: false,
            settings: {
                temperature: 0.7,
                maxTokens: CONFIG.DEFAULT_MAX_TOKENS,
                volume: 0.8,
                speechRate: 1.0,
                speechPitch: 1.0,
                autoScroll: true,
                showTimestamps: true
            }
        };

        // Speech synthesis
        let speechSynth = window.speechSynthesis;
        let voices = [];

        // ==================== API CONFIGURATION ====================
        // Auto-detect API URL based on how the page is loaded
        // - If served from server: use relative URLs (same origin)
        // - If opened as file or from GitHub Pages: use configured server
        const API_CONFIG = {
            // Set this to your server address when using GitHub Pages or file://
            // Examples: 'http://localhost:8080', 'http://192.168.1.100:8080', 'https://your-server.com'
            serverUrl: (function() {
                try { return localStorage.getItem('unity_api_url') || ''; }
                catch (e) { return ''; }
            })(),
            csrfToken: null,  // CSRF token for secure POST/PUT/DELETE requests

            getBaseUrl: function() {
                // If a custom server URL is set, use it
                if (this.serverUrl) {
                    return this.serverUrl;
                }
                // If loaded from file:// or GitHub Pages, need a server URL
                if (window.location.protocol === 'file:' ||
                    window.location.hostname.includes('github.io')) {
                    return ''; // Will fail - user needs to set serverUrl
                }
                // Otherwise use same origin (relative URLs)
                return '';
            },

            setServerUrl: function(url) {
                this.serverUrl = url.replace(/\/$/, ''); // Remove trailing slash
                try {
                    localStorage.setItem('unity_api_url', this.serverUrl);
                } catch (e) {
                    // private browsing - URL won't persist
                }
                log(`API server set to: ${this.serverUrl || 'same origin'}`, 'success');
                // refresh CSRF token when server changes
                fetchCsrfToken();
            }
        };

        // fetch CSRF token from server - needed for POST/PUT/DELETE security
        async function fetchCsrfToken() {
            try {
                const baseUrl = API_CONFIG.getBaseUrl();
                const response = await fetch(baseUrl + '/api/csrf-token', {
                    credentials: 'include'
                });
                if (response.ok) {
                    const data = await response.json();
                    API_CONFIG.csrfToken = data.csrf_token;
                    log('CSRF token loaded', 'success');
                }
            } catch (error) {
                log('Failed to get CSRF token - some features may not work', 'warning');
            }
        }

        // Track online/offline state
        let isServerOnline = false;

        // Retry with exponential backoff - for network resilience
        async function fetchWithRetry(url, options = {}, maxRetries = 3) {
            let lastError;
            for (let attempt = 0; attempt < maxRetries; attempt++) {
                try {
                    const response = await fetch(url, options);
                    return response;
                } catch (error) {
                    lastError = error;
                    if (attempt < maxRetries - 1) {
                        // exponential backoff: 1s, 2s, 4s
                        const delay = Math.pow(2, attempt) * 1000;
                        log(`Request failed, retry ${attempt + 1}/${maxRetries - 1} in ${delay/1000}s...`, 'warning');
                        await new Promise(resolve => setTimeout(resolve, delay));
                    }
                }
            }
            throw lastError;
        }

        // Helper function for all API calls - auto-adds CSRF token to POST/PUT/DELETE
        async function apiCall(endpoint, options = {}) {
            // Check if browser is offline first
            if (!navigator.onLine) {
                updateConnectionStatus(false, 'Browser offline');
                throw new Error('No internet connection');
            }

            const baseUrl = API_CONFIG.getBaseUrl();
            const url = baseUrl + endpoint;

            // add CSRF token to headers for state-changing requests
            const method = (options.method || 'GET').toUpperCase();
            if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(method)) {
                options.headers = options.headers || {};
                if (API_CONFIG.csrfToken) {
                    options.headers['X-CSRFToken'] = API_CONFIG.csrfToken;
                }
                options.credentials = 'include';
            }

            // determine retry count - GET requests retry 3x, others retry 1x (no retry)
            const retries = method === 'GET' ? 3 : 1;

            try {
                const response = await fetchWithRetry(url, options, retries);
                if (!isServerOnline) {
                    isServerOnline = true;
                    updateConnectionStatus(true);
                }
                return response;
            } catch (error) {
                isServerOnline = false;
                updateConnectionStatus(false, error.message);

                // If failed and no server configured, show helpful message
                if (!API_CONFIG.serverUrl &&
                    (window.location.protocol === 'file:' || window.location.hostname.includes('github.io'))) {
                    log('No server configured. Click Settings to set server URL.', 'error');
                }
                throw error;
            }
        }

        // Update UI to show connection status
        function updateConnectionStatus(online, reason = '') {
            const statusEl = document.getElementById('connectionStatus');
            if (!statusEl) return;

            if (online) {
                statusEl.textContent = '🟢 Connected';
                statusEl.style.color = 'var(--success)';
                statusEl.title = 'Server connection active';
            } else {
                statusEl.textContent = '🔴 Offline';
                statusEl.style.color = 'var(--error)';
                statusEl.title = reason || 'Server unavailable';
                addSystemMessage(`Connection lost: ${reason || 'Server unavailable'}. Check your server or network.`);
            }
        }

        // Listen for browser online/offline events
        window.addEventListener('online', () => {
            log('Browser back online, reconnecting...', 'info');
            pollServerStatus();  // trigger immediate status check
        });

        window.addEventListener('offline', () => {
            isServerOnline = false;
            updateConnectionStatus(false, 'Browser offline');
            log('Browser went offline', 'warning');
        });

        // ==================== INITIALIZATION ====================
        document.addEventListener('DOMContentLoaded', () => {
            loadVoices();
            loadFromStorage();
            fetchCsrfToken();  // get CSRF token for secure requests
            setupKeyboardShortcuts();
            checkFirstTimeUser();  // show setup wizard if first visit
            log('Unity AI Lab initialized', 'success');
        });

        // ==================== MODEL DOWNLOAD ====================
        let availableModelsData = null;
        let downloadProgressInterval = null;

        async function checkFirstTimeUser() {
            // Check if server is already running with models loaded
            // If so, skip the download wizard and go straight to chat
            try {
                const statusResponse = await fetch(getApiUrl('/api/status'));
                if (statusResponse.ok) {
                    const status = await statusResponse.json();
                    if (status.model_loaded) {
                        // Server running with model loaded - skip wizard, go to chat
                        log(`Reconnected to server - model already loaded: ${status.model_name}`, 'success');
                        initializeApp();
                        return;
                    }
                }
            } catch (e) {
                // Server not running, show wizard
                log('Server not responding, showing setup wizard...', 'info');
            }

            // Show model download wizard if server not ready or no model loaded
            log('Loading model download wizard...', 'info');
            await showModelDownloadModal();
        }

        async function showModelDownloadModal() {
            const modal = document.getElementById('modelDownloadModal');
            if (!modal) {
                log('Model download modal not found in HTML', 'error');
                return;
            }

            // Fetch available models from server
            try {
                log('Fetching available models from server...', 'info');
                const response = await fetch(getApiUrl('/api/download/models'));
                if (response.ok) {
                    availableModelsData = await response.json();
                    log(`Found ${Object.keys(availableModelsData.text || {}).length} text models, ${Object.keys(availableModelsData.image || {}).length} image models`, 'info');
                    populateModelLists();

                    // Auto-start download if default models not installed
                    autoDownloadDefaults();
                } else {
                    log(`Could not fetch model list: ${response.status}`, 'warning');
                }
            } catch (e) {
                log(`Server error fetching models: ${e.message}`, 'warning');
            }

            // Always show the modal
            modal.style.display = 'flex';
        }

        function autoDownloadDefaults() {
            // Check if default models need downloading and auto-start
            if (!availableModelsData) return;

            let needsDownload = false;

            // Check text models
            for (const [key, model] of Object.entries(availableModelsData.text || {})) {
                if (model.default && !model.installed) {
                    needsDownload = true;
                    break;
                }
            }

            // Check image models
            if (!needsDownload) {
                for (const [key, model] of Object.entries(availableModelsData.image || {})) {
                    if (model.default && !model.installed) {
                        needsDownload = true;
                        break;
                    }
                }
            }

            if (needsDownload) {
                log('Default models not installed - starting automatic download...', 'info');
                // Small delay to let UI render first
                setTimeout(() => {
                    startModelDownload();
                }, 500);
            }
        }

        function populateModelLists() {
            if (!availableModelsData) {
                log('No model data to populate', 'warning');
                return;
            }

            const textList = document.getElementById('textModelsList');
            const imageList = document.getElementById('imageModelsList');

            if (!textList || !imageList) {
                log('Model list elements not found in DOM', 'error');
                return;
            }

            // Clear lists
            textList.innerHTML = '';
            imageList.innerHTML = '';

            // Populate text models
            const textModels = availableModelsData.text || {};
            for (const [key, model] of Object.entries(textModels)) {
                textList.appendChild(createModelItem('text', key, model));
            }

            // Populate image models
            const imageModels = availableModelsData.image || {};
            for (const [key, model] of Object.entries(imageModels)) {
                imageList.appendChild(createModelItem('image', key, model));
            }

            log(`Populated ${Object.keys(textModels).length} text models, ${Object.keys(imageModels).length} image models`, 'info');
            updateTotalDownloadSize();
        }

        function createModelItem(type, key, model) {
            const div = document.createElement('div');
            div.className = `model-download-item ${model.installed ? 'installed' : ''}`;

            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.id = `model-${type}-${key}`;
            checkbox.dataset.type = type;
            checkbox.dataset.key = key;
            checkbox.dataset.size = model.size_gb;
            // Check default models by default (if not already installed)
            checkbox.checked = model.default && !model.installed;
            checkbox.disabled = model.installed;
            checkbox.addEventListener('change', updateTotalDownloadSize);

            const info = document.createElement('div');
            info.className = 'model-download-info';

            const name = document.createElement('div');
            name.className = 'model-download-name';
            name.textContent = model.name;
            if (model.default) {
                const badge = document.createElement('span');
                badge.className = 'default-badge';
                badge.textContent = 'Default';
                name.appendChild(badge);
            }
            if (model.installed) {
                const badge = document.createElement('span');
                badge.className = 'installed-badge';
                badge.textContent = 'Installed';
                name.appendChild(badge);
            }

            const desc = document.createElement('div');
            desc.className = 'model-download-desc';
            desc.textContent = model.description;

            info.appendChild(name);
            info.appendChild(desc);

            const size = document.createElement('div');
            size.className = 'model-download-size';
            size.textContent = `${model.size_gb} GB`;

            div.appendChild(checkbox);
            div.appendChild(info);
            div.appendChild(size);

            return div;
        }

        function updateTotalDownloadSize() {
            const checkboxes = document.querySelectorAll('.model-download-item input[type="checkbox"]:checked:not(:disabled)');
            let total = 0;
            checkboxes.forEach(cb => {
                total += parseFloat(cb.dataset.size) || 0;
            });
            document.getElementById('totalDownloadSize').textContent = `${total.toFixed(1)} GB`;

            // Update button state
            const btn = document.getElementById('startDownloadBtn');
            if (btn) {
                btn.disabled = checkboxes.length === 0;
                btn.textContent = checkboxes.length === 0 ? 'Select Models' : `Download Selected (${checkboxes.length})`;
            }
        }

        function skipModelDownload() {
            const modal = document.getElementById('modelDownloadModal');
            if (modal) modal.style.display = 'none';
            log('Model download skipped - add models manually to models/ folder', 'info');

            // Always show setup wizard for name input
            showSetupWizard();
        }

        async function startModelDownload() {
            const checkboxes = document.querySelectorAll('.model-download-item input[type="checkbox"]:checked:not(:disabled)');
            if (checkboxes.length === 0) {
                log('No models selected for download', 'warning');
                return;
            }

            // Build list of models to download
            const models = [];
            checkboxes.forEach(cb => {
                models.push({ type: cb.dataset.type, key: cb.dataset.key });
            });

            // Switch to progress view
            document.getElementById('modelSelectBody').style.display = 'none';
            document.getElementById('modelSelectFooter').style.display = 'none';
            document.getElementById('modelDownloadProgress').style.display = 'block';
            document.getElementById('modelDownloadFooter').style.display = 'flex';

            // Start download on server
            try {
                const response = await fetch(getApiUrl('/api/download/start'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ models })
                });

                if (!response.ok) {
                    const err = await response.json();
                    throw new Error(err.error || 'Failed to start download');
                }

                log(`Starting download of ${models.length} model(s)...`, 'info');

                // Start polling for progress
                downloadProgressInterval = setInterval(pollDownloadProgress, 500);

            } catch (e) {
                log(`Download error: ${e.message}`, 'error');
                document.getElementById('downloadCompleteBtn').style.display = 'block';
                document.getElementById('downloadCompleteBtn').textContent = 'Continue (Download Failed)';
            }
        }

        async function pollDownloadProgress() {
            try {
                const response = await fetch(getApiUrl('/api/download/progress'));
                if (!response.ok) return;

                const progress = await response.json();

                // Update UI
                document.getElementById('downloadCurrentModel').textContent = progress.current_model || '--';
                document.getElementById('downloadModelCount').textContent = `${progress.completed_models} / ${progress.total_models}`;

                // Speed
                const speedMB = (progress.speed_bps / (1024 * 1024)).toFixed(2);
                document.getElementById('downloadSpeed').textContent = `${speedMB} MB/s`;

                // Progress bar
                if (progress.total_bytes > 0) {
                    const percent = (progress.current_bytes / progress.total_bytes) * 100;
                    document.getElementById('downloadProgressBar').style.width = `${percent}%`;
                    document.getElementById('downloadPercent').textContent = `${percent.toFixed(1)}%`;
                    document.getElementById('downloadedBytes').textContent = formatBytes(progress.current_bytes);
                    document.getElementById('totalBytes').textContent = formatBytes(progress.total_bytes);
                }

                // Console log
                const consoleEl = document.getElementById('downloadConsole');
                consoleEl.innerHTML = '';
                progress.log.forEach(entry => {
                    const div = document.createElement('div');
                    div.className = `download-console-entry ${entry.level}`;
                    div.innerHTML = `<span class="time">[${entry.time}]</span><span class="message">${entry.message}</span>`;
                    consoleEl.appendChild(div);
                });
                consoleEl.scrollTop = consoleEl.scrollHeight;

                // Check if complete
                if (!progress.active && (progress.status === 'complete' || progress.status === 'error')) {
                    clearInterval(downloadProgressInterval);
                    downloadProgressInterval = null;

                    document.getElementById('downloadCompleteBtn').style.display = 'block';
                    if (progress.status === 'complete') {
                        log('All models downloaded successfully!', 'success');
                        document.getElementById('downloadCompleteBtn').textContent = 'Continue Setup';
                    } else {
                        log(`Download finished with errors: ${progress.error}`, 'error');
                        document.getElementById('downloadCompleteBtn').textContent = 'Continue (Some downloads failed)';
                    }
                }

            } catch (e) {
                // Ignore polling errors
            }
        }

        function formatBytes(bytes) {
            if (bytes < 1024) return `${bytes} B`;
            if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
            if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
            return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
        }

        function completeModelDownload() {
            const modal = document.getElementById('modelDownloadModal');
            if (modal) modal.style.display = 'none';

            // Reset modal state for next time
            document.getElementById('modelSelectBody').style.display = 'block';
            document.getElementById('modelSelectFooter').style.display = 'flex';
            document.getElementById('modelDownloadProgress').style.display = 'none';
            document.getElementById('modelDownloadFooter').style.display = 'none';
            document.getElementById('downloadCompleteBtn').style.display = 'none';

            // Refresh model list since new models were downloaded
            fetchModels();
            log('Model download complete! New models are now available.', 'success');

            // Always show setup wizard for name input
            showSetupWizard();
        }

        // Open model download wizard from settings
        function openModelDownloadWizard() {
            // Close settings modal first
            const settingsModal = document.getElementById('settingsModal');
            if (settingsModal) settingsModal.style.display = 'none';

            // Show model download modal
            showModelDownloadModal();
        }

        // ==================== SETUP WIZARD ====================
        function showSetupWizard() {
            const modal = document.getElementById('setupWizardModal');
            if (modal) {
                modal.style.display = 'flex';
            }
        }

        function skipSetupWizard() {
            const modal = document.getElementById('setupWizardModal');
            if (modal) {
                modal.style.display = 'none';
            }
            try {
                localStorage.setItem('unity_setup_complete', 'true');
            } catch (e) {}
            log('Setup skipped - use Settings to configure later', 'info');
        }

        function completeSetupWizard() {
            // Get wizard values
            const serverUrl = document.getElementById('wizardServerUrl')?.value?.trim();
            const userName = document.getElementById('wizardUserName')?.value?.trim();
            const enableTTS = document.getElementById('wizardEnableTTS')?.checked;

            // Apply server URL
            if (serverUrl) {
                API_CONFIG.serverUrl = serverUrl;
                try {
                    localStorage.setItem('unity_api_url', serverUrl);
                } catch (e) {}
                log(`Server URL set: ${serverUrl}`, 'success');
            }

            // Apply user name to memory
            if (userName) {
                state.memoryText = `My name is ${userName}.`;
                updateMemoryDisplay();
                saveToStorage();
                log(`Memory set: Your name is ${userName}`, 'success');
            }

            // Apply TTS setting
            if (enableTTS) {
                state.ttsEnabled = true;
                const ttsCheckbox = document.getElementById('ttsEnabled');
                if (ttsCheckbox) ttsCheckbox.checked = true;
                log('Text-to-speech enabled', 'success');
            }

            // Mark setup complete
            try {
                localStorage.setItem('unity_setup_complete', 'true');
            } catch (e) {}

            // Close wizard
            const modal = document.getElementById('setupWizardModal');
            if (modal) {
                modal.style.display = 'none';
            }

            log('Setup complete! Welcome to Unity AI Lab.', 'success');
        }

        // ==================== KEYBOARD SHORTCUTS ====================
        // Global keyboard navigation for accessibility
        function setupKeyboardShortcuts() {
            document.addEventListener('keydown', (e) => {
                // Don't trigger shortcuts when typing in input fields
                const activeEl = document.activeElement;
                const isTyping = activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.isContentEditable;

                // Escape key - close any open modal/panel
                if (e.key === 'Escape') {
                    closeSettings();
                    closeImagePanel();
                    return;
                }

                // Shortcuts that work even while typing (Ctrl/Cmd + key)
                if (e.ctrlKey || e.metaKey) {
                    switch(e.key.toLowerCase()) {
                        case '/':
                            // Ctrl+/ - Focus chat input
                            e.preventDefault();
                            document.getElementById('messageInput')?.focus();
                            break;
                        case 'i':
                            // Ctrl+I - Toggle image generation panel
                            e.preventDefault();
                            toggleImagePanel();
                            break;
                        case ',':
                            // Ctrl+, - Open settings
                            e.preventDefault();
                            openSettings();
                            break;
                        case 'k':
                            // Ctrl+K - Clear current chat
                            e.preventDefault();
                            if (confirm('Clear current chat?')) {
                                clearCurrentChat();
                            }
                            break;
                        case 'n':
                            // Ctrl+N - New session
                            e.preventDefault();
                            createNewSession();
                            break;
                    }
                    return;
                }

                // Shortcuts that only work when NOT typing
                if (!isTyping) {
                    switch(e.key.toLowerCase()) {
                        case '?':
                            // ? - Show keyboard shortcuts help
                            showKeyboardShortcutsHelp();
                            break;
                        case 's':
                            // S - Toggle sessions panel
                            toggleSessionsPanel();
                            break;
                        case 'i':
                            // I - Toggle image panel
                            toggleImagePanel();
                            break;
                        case 'm':
                            // M - Focus memory textarea
                            document.getElementById('memoryText')?.focus();
                            break;
                        case 't':
                            // T - Toggle TTS
                            toggleTTS();
                            break;
                    }
                }
            });
            log('Keyboard shortcuts enabled (press ? for help)', 'info');
        }

        function showKeyboardShortcutsHelp() {
            const shortcuts = `
KEYBOARD SHORTCUTS

Navigation:
  Ctrl+/  - Focus chat input
  Ctrl+,  - Open settings
  Escape  - Close panels/modals
  ?       - Show this help

Chat:
  Enter        - Send message
  Shift+Enter  - New line
  Ctrl+K       - Clear chat
  Ctrl+N       - New session

Panels:
  S - Toggle sessions
  I - Toggle image gen
  M - Focus memory
  T - Toggle TTS

(Press anywhere to close)
            `.trim();
            alert(shortcuts);
        }

        // save immediately when user leaves the page
        window.addEventListener('beforeunload', () => {
            if (saveDebounceTimer) {
                clearTimeout(saveDebounceTimer);
                saveToStorageNow();  // flush any pending saves
            }
        });

        function loadVoices() {
            try {
                if (!window.speechSynthesis) {
                    log('Text-to-speech not supported in this browser', 'warning');
                    return;
                }
                voices = speechSynth.getVoices();
                if (voices.length === 0) {
                    speechSynth.onvoiceschanged = () => {
                        voices = speechSynth.getVoices();
                        if (voices.length > 0) {
                            populateVoiceSelect();
                        } else {
                            log('No TTS voices available', 'warning');
                        }
                    };
                } else {
                    populateVoiceSelect();
                }
            } catch (error) {
                log('TTS initialization failed: ' + error.message, 'error');
            }
        }

        function populateVoiceSelect() {
            try {
                const select = document.getElementById('ttsVoiceSelect');
                if (!select) return;
                if (voices.length === 0) {
                    select.innerHTML = '<option value="">No voices available</option>';
                    return;
                }
                select.innerHTML = voices.map((voice, i) =>
                    `<option value="${i}">${voice.name} (${voice.lang})</option>`
                ).join('');
                // auto-select British female voice if available
                if (typeof selectBritishFemaleVoice === 'function') {
                    selectBritishFemaleVoice();
                }
                // update the header button to show voice name
                updateTTSButtonText();
            } catch (error) {
                log('Failed to populate voice list: ' + error.message, 'error');
            }
        }

        function loadFromStorage() {
            try {
                // Load sessions
                const savedSessions = localStorage.getItem('unity_sessions');
                if (savedSessions) {
                    state.sessions = JSON.parse(savedSessions);
                }

                // Load trashed sessions
                const savedTrash = localStorage.getItem('unity_trashed_sessions');
                if (savedTrash) {
                    state.trashedSessions = JSON.parse(savedTrash);
                }

                // Load memory text
                const savedMemory = localStorage.getItem('unity_memory_text');
                if (savedMemory) {
                    state.memoryText = savedMemory;
                }

                // Load settings
                const savedSettings = localStorage.getItem('unity_settings');
                if (savedSettings) {
                    state.settings = { ...state.settings, ...JSON.parse(savedSettings) };
                }
            } catch (e) {
                // localStorage may be blocked in private browsing mode
                log('Local storage unavailable (private browsing?). Data won\'t persist.', 'warning');
            }

            updateMemoryDisplay();
            updateSessionList();
        }

        // debounce timer for localStorage saves
        let saveDebounceTimer = null;

        // ==================== CROSS-TAB SYNC ====================
        // BroadcastChannel keeps multiple tabs in sync
        let tabSyncChannel = null;
        try {
            tabSyncChannel = new BroadcastChannel('unity_ai_lab_sync');
            tabSyncChannel.onmessage = (event) => {
                if (event.data.type === 'state_update') {
                    // reload state from storage (another tab saved changes)
                    loadFromStorage();
                    log('Synced from another tab', 'info');
                } else if (event.data.type === 'session_switch') {
                    // another tab switched sessions - don't auto-switch but notify
                    log(`Another tab switched to: ${event.data.sessionName}`, 'info');
                }
            };
        } catch (e) {
            // BroadcastChannel not supported (older browsers)
        }

        function broadcastStateUpdate() {
            if (tabSyncChannel) {
                try {
                    tabSyncChannel.postMessage({ type: 'state_update' });
                } catch (e) {}
            }
        }

        function broadcastSessionSwitch(sessionName) {
            if (tabSyncChannel) {
                try {
                    tabSyncChannel.postMessage({ type: 'session_switch', sessionName });
                } catch (e) {}
            }
        }

        function saveToStorage() {
            // debounce - wait 500ms after last call before actually saving
            // this prevents hammering localStorage on every keystroke/message
            if (saveDebounceTimer) {
                clearTimeout(saveDebounceTimer);
            }
            saveDebounceTimer = setTimeout(saveToStorageNow, 500);
        }

        function saveToStorageNow() {
            try {
                // Limit sessions to prevent quota exceeded - keep only last 20 sessions
                const sessionsToSave = state.sessions.slice(0, 20).map(session => ({
                    ...session,
                    // Limit messages per session to last 50
                    messages: (session.messages || []).slice(-50)
                }));
                localStorage.setItem('unity_sessions', JSON.stringify(sessionsToSave));
                localStorage.setItem('unity_memory_text', state.memoryText);
                localStorage.setItem('unity_settings', JSON.stringify(state.settings));
                // save trash - limit to 10 trashed sessions to save space
                const trashToSave = state.trashedSessions.slice(0, 10);
                localStorage.setItem('unity_trashed_sessions', JSON.stringify(trashToSave));
                // notify other tabs
                broadcastStateUpdate();
            } catch (e) {
                // Check if it's actually a quota error (not private browsing or other issue)
                if (e.name === 'QuotaExceededError' || (e.message && e.message.includes('quota'))) {
                    // Silently trim to minimal sessions without warning user
                    const minimalSessions = state.sessions.slice(0, 5).map(session => ({
                        ...session,
                        messages: (session.messages || []).slice(-20)
                    }));
                    try {
                        localStorage.setItem('unity_sessions', JSON.stringify(minimalSessions));
                    } catch (e2) {
                        // Last resort - clear sessions entirely (silently)
                        if (e2.name === 'QuotaExceededError' || (e2.message && e2.message.includes('quota'))) {
                            try {
                                localStorage.removeItem('unity_sessions');
                            } catch (e3) {
                                // localStorage completely broken, just silently fail
                            }
                        }
                    }
                }
                // For all errors, silently fail - data just won't persist but app still works
            }
        }

        // ==================== SERVER SYNC ====================
        // sync current session to server - call after any session change
        async function syncSessionToServer(session) {
            if (!session) return;
            try {
                await apiCall(`/api/sessions/${session.id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(session)
                });
            } catch (error) {
                console.debug('Session sync failed:', error.message);
            }
        }

        // sync memory text to server
        async function syncMemoryToServer() {
            try {
                await apiCall('/api/memories', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        key: 'user_memory',
                        value: state.memoryText
                    })
                });
            } catch (error) {
                console.debug('Memory sync failed:', error.message);
            }
        }

        // load memory from server
        async function loadMemoryFromServer() {
            try {
                const response = await apiCall('/api/memories');
                if (response.ok) {
                    const data = await response.json();
                    if (data.memories && data.memories.user_memory) {
                        state.memoryText = data.memories.user_memory;
                        updateMemoryDisplay();
                        log('Memory loaded from server', 'success');
                    }
                }
            } catch (error) {
                console.debug('Memory load failed:', error.message);
            }
        }

        // ==================== LANDING PAGE ====================
        function launchApp() {
            document.getElementById('landingPage').classList.add('hidden');
            document.getElementById('appContainer').classList.add('active');
            initializeApp();
        }

        function showLanding() {
            document.getElementById('landingPage').classList.remove('hidden');
            document.getElementById('appContainer').classList.remove('active');
        }

        async function initializeApp() {
            await loadModels();
            await loadImageModels();
            await checkServerStatus();
            await loadMemoryFromServer();  // try to load memory from server

            if (state.sessions.length === 0) {
                newSession();
            } else {
                loadSession(state.sessions[0].id);
            }

            // Auto-refresh status - smart polling
            startSmartPolling();

            // Check if we should refresh the AI avatar on page load
            // This happens if avatar is older than 24 hours
            if (checkAvatarRefresh()) {
                log('Avatar refresh scheduled for next image model load', 'info');
            }
        }

        // ==================== SERVER COMMUNICATION ====================
        let serverOnline = false;
        let pollTimeoutId = null;

        function startSmartPolling() {
            async function poll() {
                await checkServerStatus();
                // if offline, poll slowly (60s). if online, poll faster (30s)
                const delay = serverOnline ? CONFIG.POLL_INTERVAL_ONLINE : CONFIG.POLL_INTERVAL_OFFLINE;
                pollTimeoutId = setTimeout(poll, delay);
            }
            poll();
        }

        async function checkServerStatus() {
            try {
                const response = await apiCall('/api/status');
                const data = await response.json();

                serverOnline = true;
                if (data.model_loaded) {
                    updateStatus('online', `Ready: ${data.model_name}`);
                } else {
                    updateStatus('warning', 'Server ready - select a model');
                }

                state.currentModel = data.model_path;
            } catch (error) {
                serverOnline = false;
                updateStatus('offline', 'Server offline - check if running');
            }
        }

        // Default model preferences
        const DEFAULT_TEXT_MODEL = 'Mistral-7B-Instruct-v0.3.Q4_K_M';
        const DEFAULT_IMAGE_MODEL = 'ponyRealism_V22';

        async function loadModels() {
            try {
                const response = await apiCall('/api/models');
                const data = await response.json();

                state.availableModels = data.models || [];
                state.currentModel = data.current_model;

                updateModelSelects();

                // Auto-load default text model if no model is loaded
                if (!state.currentModel && state.availableModels.length > 0) {
                    const defaultModel = state.availableModels.find(m =>
                        m.name.includes(DEFAULT_TEXT_MODEL) || m.path.includes(DEFAULT_TEXT_MODEL)
                    );
                    if (defaultModel) {
                        log(`Auto-selecting default text model: ${defaultModel.name}`, 'info');
                        document.getElementById('modelSelect').value = defaultModel.path;
                        onModelSelect();
                    } else {
                        log('Default text model not found. Please select a model.', 'warning');
                    }
                }
            } catch (error) {
                // server may be starting - log but don't show to user
                console.debug('loadModels failed (server starting?):', error.message);
            }
        }

        function updateModelSelects() {
            const selects = [
                document.getElementById('modelSelect'),
                document.getElementById('settingsModelSelect')
            ];

            selects.forEach(select => {
                if (!select) return;

                if (state.availableModels.length === 0) {
                    select.innerHTML = '<option value="">No models found</option>';
                    return;
                }

                // Add a placeholder option if no model is loaded
                let options = '';
                if (!state.currentModel) {
                    options = '<option value="" disabled selected>-- Select a Text Model --</option>';
                }

                options += state.availableModels.map(model =>
                    `<option value="${model.path}" ${model.path === state.currentModel ? 'selected' : ''}>
                        ${model.name} (${model.size_gb}GB)
                    </option>`
                ).join('');

                select.innerHTML = options;
            });
        }

        async function onModelSelect() {
            const select = document.getElementById('modelSelect');
            const modelPath = select.value;

            // Skip if empty or same model
            if (!modelPath || modelPath === state.currentModel) {
                return;
            }

            // show loading state
            select.disabled = true;
            select.style.opacity = '0.5';
            select.style.cursor = 'wait';

            // get model name for progress logs
            const modelName = select.options[select.selectedIndex]?.text || modelPath;
            updateStatus('loading', `Loading: ${modelName.split(' ')[0]}...`);
            log(`⏳ Loading text model: ${modelName}`, 'info');
            log('→ Initializing model parameters...', 'info');
            addSystemMessage('Loading model... Please wait.');

            const loadStart = Date.now();

            try {
                log('→ Sending load request to server...', 'info');
                const response = await apiCall('/api/models/load', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ model_path: modelPath })
                });

                const data = await response.json();

                if (!response.ok || data.error) {
                    throw new Error(data.error || `HTTP ${response.status}`);
                }

                const loadTime = ((Date.now() - loadStart) / 1000).toFixed(1);
                state.currentModel = data.model_path;
                updateStatus('online', `Ready: ${data.model_name}`);
                log(`✅ Model loaded in ${loadTime}s: ${data.model_name}`, 'success');
                addSystemMessage(`Model loaded: ${data.model_name}`);

                // Update the settings dropdown to match
                const settingsSelect = document.getElementById('settingsModelSelect');
                if (settingsSelect) {
                    settingsSelect.value = data.model_path;
                }
            } catch (error) {
                updateStatus('offline', 'Load failed');
                addSystemMessage(`Failed to load model: ${error.message}`);

                // Reset dropdown to show placeholder if no model loaded
                if (!state.currentModel) {
                    updateModelSelects();
                }
            } finally {
                // restore dropdown state
                select.disabled = false;
                select.style.opacity = '';
                select.style.cursor = '';
            }
        }

        function updateStatus(status, text) {
            const dot = document.getElementById('statusDot');
            const textEl = document.getElementById('statusText');

            dot.className = 'status-dot';
            if (status === 'online') dot.classList.add('online');
            else if (status === 'loading') dot.classList.add('loading');
            else if (status === 'offline') dot.classList.add('offline');

            textEl.textContent = text;
        }

        // context window size for common models (in tokens)
        const MODEL_CONTEXT_SIZES = {
            'mistral': 8192,
            'llama': 8192,
            'phi': 4096,
            'qwen': 32768,
            'default': 8192
        };

        function getModelContextSize() {
            // try to detect context size from model name
            const modelName = (state.currentModel || '').toLowerCase();
            for (const [key, size] of Object.entries(MODEL_CONTEXT_SIZES)) {
                if (modelName.includes(key)) return size;
            }
            return MODEL_CONTEXT_SIZES.default;
        }

        function updateMetricsDisplay(tokensPerSec, totalTokens, promptTokens) {
            const speedEl = document.getElementById('metricsSpeed');
            const contextEl = document.getElementById('metricsContext');

            // update speed display
            speedEl.textContent = `⚡ ${tokensPerSec} tok/s`;

            // update context usage with color coding
            const contextSize = getModelContextSize();
            const usagePercent = Math.round((promptTokens / contextSize) * 100);

            contextEl.textContent = `📊 ${promptTokens}/${contextSize} (${usagePercent}%)`;
            contextEl.className = '';

            if (usagePercent >= 90) {
                contextEl.classList.add('danger');
                log(`⚠️ WARNING: Context window ${usagePercent}% full! Responses may be truncated.`, 'warning');
            } else if (usagePercent >= 70) {
                contextEl.classList.add('warning');
            }
        }

        // ==================== SESSIONS ====================
        // generate a sassy session name from the first message
        async function generateSessionName(firstMessage) {
            try {
                const response = await apiCall('/api/chat', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        message: `Summarize this in 3-5 words max, sassy goth girl style, no quotes, no punctuation at end: "${firstMessage.substring(0, 200)}"`,
                        history: [],
                        temperature: 0.9,
                        max_tokens: 20
                    })
                });

                if (response.ok) {
                    const data = await response.json();
                    let name = data.response.trim();
                    // clean up - remove quotes, limit length
                    name = name.replace(/^["']|["']$/g, '').substring(0, 40);
                    if (name && name.length > 2) {
                        return name;
                    }
                }
            } catch (error) {
                console.debug('Session name generation failed:', error);
            }
            // fallback to truncated first message
            return firstMessage.substring(0, 30) + (firstMessage.length > 30 ? '...' : '');
        }

        function newSession() {
            const session = {
                id: generateUUID(),
                name: `Session ${state.sessions.length + 1}`,
                messages: [],
                created: new Date().toISOString(),
                nameGenerated: false  // track if we've generated a name yet
            };

            state.sessions.unshift(session);
            state.currentSession = session;

            saveToStorage();
            syncSessionToServer(session);  // sync new session to server
            updateSessionList();

            document.getElementById('chatMessages').innerHTML = '';
            addSystemMessage('New session started.');

            log(`New session created: ${session.name}`, 'info');
        }

        function loadSession(sessionId) {
            const session = state.sessions.find(s => s.id === sessionId);
            if (!session) return;

            state.currentSession = session;
            updateSessionList();

            // notify other tabs
            broadcastSessionSwitch(session.name);

            // show loading state for large sessions
            const container = document.getElementById('chatMessages');
            const messageCount = session.messages.length;

            if (messageCount > CONFIG.LARGE_SESSION_THRESHOLD) {
                container.innerHTML = '<div class="system-message" style="text-align:center;padding:2rem;">Loading ' + messageCount + ' messages...</div>';
                // use setTimeout to let the loading message render first
                setTimeout(() => renderSessionMessages(session, container), 10);
            } else {
                renderSessionMessages(session, container);
            }

            log(`Loaded session: ${session.name}`, 'info');
        }

        async function renderSessionMessages(session, container) {
            container.innerHTML = '';

            for (const msg of session.messages) {
                // check if message has an image (new format: imageId/imageData, old format: image)
                if (msg.imageId || msg.imageData || msg.image) {
                    // migrate old 'image' field to new format if needed
                    if (msg.image && !msg.imageData && !msg.imageId) {
                        msg.imageData = msg.image;
                        delete msg.image;
                    }
                    await renderImageMessage(msg);
                } else {
                    renderMessage(msg.role, msg.content, msg.timestamp, false);
                }
            }

            if (session.messages.length === 0) {
                addSystemMessage('Session loaded.');
            }
        }

        async function renderImageMessage(msg) {
            const container = document.getElementById('chatMessages');
            const div = document.createElement('div');
            div.className = 'message assistant';

            // load image from IndexedDB if stored there, otherwise use inline data
            let imageData = msg.imageData;
            if (msg.imageId && !imageData) {
                imageData = await loadFromIndexedDB(msg.imageId);
            }

            const promptEscaped = escapeHtml(msg.imagePrompt || 'image');

            if (imageData) {
                div.innerHTML = `
                    <div class="message-content">
                        <p><em>Generated image: "${promptEscaped}"</em></p>
                        <img src="data:image/png;base64,${imageData}"
                             alt="${promptEscaped}"
                             style="max-width: 100%; border-radius: 8px; margin-top: 0.5rem; cursor: pointer;"
                             onclick="window.open(this.src, '_blank')">
                        <div style="margin-top: 0.5rem;">
                            <button class="msg-action-btn" onclick="editImagePrompt('${promptEscaped.replace(/'/g, "\\'")}')" title="Edit this prompt in the image panel" style="font-size: 0.75rem; padding: 0.3rem 0.6rem;">
                                ✏️ Edit Prompt
                            </button>
                        </div>
                    </div>
                `;
            } else {
                // image was lost (cleared IndexedDB) - show placeholder
                div.innerHTML = `
                    <div class="message-content">
                        <p><em>Generated image: "${promptEscaped}"</em></p>
                        <div style="padding: 2rem; background: var(--bg-tertiary); border-radius: 8px; text-align: center; color: var(--text-dim);">
                            [Image no longer available]
                        </div>
                        <div style="margin-top: 0.5rem;">
                            <button class="msg-action-btn" onclick="editImagePrompt('${promptEscaped.replace(/'/g, "\\'")}')" title="Regenerate with this prompt" style="font-size: 0.75rem; padding: 0.3rem 0.6rem;">
                                🔄 Regenerate
                            </button>
                        </div>
                    </div>
                `;
            }

            container.appendChild(div);
        }

        function editImagePrompt(prompt) {
            // load prompt into image panel
            const promptInput = document.getElementById('imagePrompt');
            if (promptInput) {
                promptInput.value = prompt;
            }
            // open image panel and switch to image tab
            toggleImagePanel();
            log(`Loaded prompt into image panel: "${prompt.substring(0, 50)}..."`, 'info');
        }

        function deleteSession(sessionId, event) {
            event.stopPropagation();

            // find session and move to trash instead of deleting
            const sessionIndex = state.sessions.findIndex(s => s.id === sessionId);
            if (sessionIndex !== -1) {
                const session = state.sessions[sessionIndex];
                session.trashedAt = Date.now();  // timestamp for auto-cleanup
                state.trashedSessions.push(session);
                state.sessions.splice(sessionIndex, 1);
            }

            if (state.currentSession?.id === sessionId) {
                if (state.sessions.length > 0) {
                    loadSession(state.sessions[0].id);
                } else {
                    newSession();
                }
            }

            saveToStorage();
            updateSessionList();
            log('Session moved to trash (can recover from settings)', 'info');
        }

        function restoreSession(sessionId) {
            const index = state.trashedSessions.findIndex(s => s.id === sessionId);
            if (index !== -1) {
                const session = state.trashedSessions[index];
                delete session.trashedAt;  // clean up trash metadata
                state.sessions.unshift(session);  // add to top of list
                state.trashedSessions.splice(index, 1);
                saveToStorage();
                updateSessionList();
                updateTrashList();
                log(`Session "${session.name}" restored`, 'success');
            }
        }

        function permanentlyDeleteSession(sessionId) {
            state.trashedSessions = state.trashedSessions.filter(s => s.id !== sessionId);
            saveToStorage();
            updateTrashList();
            log('Session permanently deleted', 'info');
        }

        function emptyTrash() {
            if (state.trashedSessions.length === 0) {
                log('Trash is already empty', 'info');
                return;
            }
            if (confirm(`Permanently delete ${state.trashedSessions.length} session(s)? This cannot be undone.`)) {
                state.trashedSessions = [];
                saveToStorage();
                updateTrashList();
                log('Trash emptied', 'success');
            }
        }

        function updateTrashList() {
            const container = document.getElementById('trashList');
            if (!container) return;

            if (state.trashedSessions.length === 0) {
                container.innerHTML = '<div style="padding: 1rem; color: var(--text-dim); text-align: center;">Trash is empty</div>';
                return;
            }

            container.innerHTML = state.trashedSessions.map(session => `
                <div class="trash-item" style="display: flex; justify-content: space-between; align-items: center; padding: 0.5rem; border-bottom: 1px solid var(--glass-border);">
                    <div>
                        <div style="color: var(--text-primary);">${escapeHtml(session.name)}</div>
                        <div style="font-size: 0.7rem; color: var(--text-dim);">Deleted ${new Date(session.trashedAt).toLocaleDateString()}</div>
                    </div>
                    <div style="display: flex; gap: 0.3rem;">
                        <button onclick="restoreSession('${session.id}')" title="Restore this session" style="background: var(--success); border: none; color: white; padding: 0.3rem 0.5rem; cursor: pointer; border-radius: 4px; font-size: 0.75rem;">↩</button>
                        <button onclick="permanentlyDeleteSession('${session.id}')" title="Delete permanently" style="background: var(--error); border: none; color: white; padding: 0.3rem 0.5rem; cursor: pointer; border-radius: 4px; font-size: 0.75rem;">✕</button>
                    </div>
                </div>
            `).join('');
        }

        function updateSessionList() {
            const container = document.getElementById('sessionList');
            container.innerHTML = state.sessions.map(session => {
                // Truncate display name but keep full name for tooltip
                const fullName = escapeHtml(session.name);
                const displayName = fullName.length > 25 ? fullName.substring(0, 22) + '...' : fullName;
                return `
                <div class="session-item ${session.id === state.currentSession?.id ? 'active' : ''}"
                     onclick="loadSession('${session.id}')"
                     title="${fullName}">
                    <div class="session-info">
                        <div class="session-name">${displayName}</div>
                        <div class="session-date">${new Date(session.created).toLocaleDateString()}</div>
                    </div>
                    <button class="session-delete" onclick="deleteSession('${session.id}', event)" title="Delete session">🗑️</button>
                </div>
            `}).join('');
        }

        // ==================== MESSAGING ====================
        function handleInputKeydown(event) {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                sendMessage();
            }
        }

        async function sendMessage() {
            const input = document.getElementById('messageInput');
            const message = input.value.trim();

            if (!message || state.isProcessing) return;

            state.isProcessing = true;
            document.getElementById('sendBtn').disabled = true;
            input.value = '';
            autoResizeTextarea(input);

            // Build message history for API BEFORE adding new message
            // This prevents the new message from being duplicated in history
            const history = state.currentSession?.messages.slice(-20) || [];

            // Add user message to UI
            const timestamp = new Date().toISOString();
            addMessage('user', message, timestamp);

            // Save to session AFTER building history
            if (state.currentSession) {
                state.currentSession.messages.push({ role: 'user', content: message, timestamp });
                saveToStorage();
            }

            log(`💬 User: "${message.substring(0, 50)}${message.length > 50 ? '...' : ''}"`, 'request');

            // Show typing indicator
            showTyping();

            const chatStart = Date.now();

            try {

                log(`→ Sending to AI (${history.length} msgs history, temp: ${state.settings.temperature})...`, 'info');

                // Include memory text in the request - with timeout for long generations
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), CONFIG.API_TIMEOUT);

                const response = await apiCall('/api/chat', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        message,
                        memory_text: state.memoryText,
                        history: history.map(m => ({role: m.role, content: m.content})),
                        temperature: state.settings.temperature,
                        max_tokens: state.settings.maxTokens
                    }),
                    signal: controller.signal
                });

                clearTimeout(timeoutId);
                hideTyping();

                const chatTime = ((Date.now() - chatStart) / 1000).toFixed(1);
                const data = await response.json();

                // calculate and display performance metrics
                if (data.tokens && data.time) {
                    const promptTokens = data.tokens.prompt_tokens || 0;
                    const completionTokens = data.tokens.completion_tokens || 0;
                    const totalTokens = promptTokens + completionTokens;
                    const tokensPerSec = data.time > 0 ? (completionTokens / data.time).toFixed(1) : '?';

                    log(`✅ Response: ${chatTime}s | ${completionTokens} tokens | ${tokensPerSec} tok/s`, 'success');
                    log(`📊 Tokens - Prompt: ${promptTokens} | Completion: ${completionTokens} | Total: ${totalTokens}`, 'info');

                    // update the metrics display in header
                    updateMetricsDisplay(tokensPerSec, totalTokens, promptTokens);
                } else {
                    log(`✅ Response received in ${chatTime}s`, 'success');
                }

                if (data.error) {
                    addMessage('assistant', `Error: ${data.error}`, null, true);
                    log(`Error: ${data.error}`, 'error');
                } else {
                    const respTimestamp = new Date().toISOString();

                    // Check if response includes an image
                    if (data.image) {
                        // Add message with embedded image (includes seed display and prompt)
                        addMessageWithImage('assistant', data.response, data.image, respTimestamp, data.image_seed, data.image_prompt);
                        log(`🎨 Image generated in ${data.image_time?.toFixed(2) || '?'}s (seed: ${data.image_seed})`, 'success');
                    } else {
                        addMessage('assistant', data.response, respTimestamp);
                    }

                    // Save to session (with proper image storage)
                    if (state.currentSession) {
                        const msgData = {
                            role: 'assistant',
                            content: data.response,
                            timestamp: respTimestamp
                        };

                        // Save image to IndexedDB if present (large images need proper storage)
                        if (data.image) {
                            const imageId = 'chatimg_' + generateUUID();
                            const imageSize = data.image.length;

                            // Store large images in IndexedDB, small ones inline
                            if (imageSize > 100000) {
                                await saveToIndexedDB(imageId, data.image);
                                msgData.imageId = imageId;
                                log(`Image stored in IndexedDB (${Math.round(imageSize/1024)}KB)`, 'info');
                            } else {
                                msgData.imageData = data.image;
                            }
                            msgData.imagePrompt = data.image_prompt || '';
                            msgData.imageSeed = data.image_seed || null;
                        }

                        state.currentSession.messages.push(msgData);
                        saveToStorage();
                        syncSessionToServer(state.currentSession);  // sync to server

                        // auto-generate session name after first exchange
                        if (!state.currentSession.nameGenerated && state.currentSession.messages.length === 2) {
                            state.currentSession.nameGenerated = true;
                            // get the first user message
                            const firstUserMsg = state.currentSession.messages.find(m => m.role === 'user');
                            if (firstUserMsg) {
                                generateSessionName(firstUserMsg.content).then(name => {
                                    state.currentSession.name = name;
                                    saveToStorage();
                                    syncSessionToServer(state.currentSession);
                                    updateSessionList();
                                    log(`Session renamed: ${name}`, 'info');
                                });
                            }
                        }
                    }

                    log(`Response: ${data.response.substring(0, 50)}...`, 'response');
                    log(`Generated in ${data.time?.toFixed(2) || '?'}s`, 'success');

                    // TTS
                    if (state.ttsEnabled) {
                        speakText(data.response);
                    }

                    // Trigger AI selfie generation on first message if image model is loaded
                    // and we don't have an avatar yet (or it's time to refresh)
                    if (!state.firstMessageSent) {
                        state.firstMessageSent = true;
                        const imageModelStatus = document.getElementById('imageModelStatus').textContent;
                        // check for "Loaded:" prefix - means image model is ready
                        const hasImageModel = imageModelStatus && imageModelStatus.startsWith('Loaded:');

                        if (hasImageModel && (!state.aiAvatar || checkAvatarRefresh())) {
                            // Generate selfie in background (don't await)
                            setTimeout(() => generateAISelfie(), 1000);
                        }
                    }
                }
            } catch (error) {
                hideTyping();
                addMessage('assistant', `Connection error: ${error.message}`, null, true);
                log(`Network error: ${error.message}`, 'error');
            }

            state.isProcessing = false;
            document.getElementById('sendBtn').disabled = false;
            document.getElementById('messageInput').focus();
        }

        function addMessage(role, content, timestamp, isError = false) {
            renderMessage(role, content, timestamp, true, isError);
        }

        // store image data for download (avoids inline base64 in onclick)
        const pendingImageDownloads = new Map();

        function addMessageWithImage(role, content, imageBase64, timestamp, seed = null, imagePrompt = '') {
            const container = document.getElementById('chatMessages');
            const div = document.createElement('div');
            div.className = `message ${role}`;

            const timeStr = timestamp ? new Date(timestamp).toLocaleTimeString() : '';
            const processedContent = processMessageContent(content);

            // Get avatar based on role
            const avatar = role === 'assistant' ? getAIAvatarHTML() : getUserAvatarHTML();

            // Seed display for reproducibility
            const seedDisplay = seed ? `<span class="image-seed" style="font-size: 0.75rem; color: var(--text-dim); font-family: 'JetBrains Mono', monospace;">Seed: ${seed}</span>` : '';

            // store image data by ID for download (avoid inline base64)
            const imageId = 'dlimg_' + Date.now();
            pendingImageDownloads.set(imageId, { base64: imageBase64, prompt: imagePrompt || '', seed: seed || '' });

            // Escape prompt for use in onclick
            const promptEscaped = escapeHtml(imagePrompt || '').replace(/'/g, "\\'");

            div.innerHTML = `
                <div class="message-wrapper">
                    ${avatar}
                    <div class="message-body">
                        <div class="message-content">
                            ${processedContent}
                            <div class="generated-image-container" style="margin-top: 1rem;">
                                <img src="data:image/png;base64,${imageBase64}"
                                     alt="Generated image"
                                     class="generated-image"
                                     style="max-width: 100%; border-radius: 8px; border: 1px solid var(--accent-primary); cursor: pointer;"
                                     onclick="openImageFullscreen(this.src)">
                                <div style="display: flex; gap: 0.5rem; margin-top: 0.5rem; align-items: center; flex-wrap: wrap;">
                                    <button class="msg-action-btn" onclick="downloadImageById('${imageId}')" title="Download image + metadata" style="padding: 0.5rem 1rem; font-size: 0.8rem;">
                                        📥 Download
                                    </button>
                                    ${imagePrompt ? `<button class="msg-action-btn" onclick="editImagePrompt('${promptEscaped}')" title="Edit this prompt in image panel" style="padding: 0.5rem 1rem; font-size: 0.8rem;">✏️ Edit</button>` : ''}
                                    ${seed ? `<button class="msg-action-btn" onclick="copySeed(${seed})" title="Copy seed to clipboard" style="padding: 0.5rem 1rem; font-size: 0.8rem;">📋 Seed</button>` : ''}
                                    ${seedDisplay}
                                </div>
                            </div>
                        </div>
                        <div class="message-meta">
                            ${state.settings.showTimestamps ? `<span>${timeStr}</span>` : ''}
                            <div class="message-actions">
                                <button class="msg-action-btn" onclick="copyMessage(this)" title="Copy">📋</button>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            container.appendChild(div);

            if (state.settings.autoScroll) {
                scrollToBottom();
            }
        }

        function downloadImageById(imageId) {
            const data = pendingImageDownloads.get(imageId);
            if (data) {
                downloadImage(data.base64, data.prompt, data.seed);
            } else {
                log('Image data not found - try downloading from the image itself', 'warning');
            }
        }

        function copySeed(seed) {
            navigator.clipboard.writeText(seed.toString()).then(() => {
                log(`Seed ${seed} copied to clipboard`, 'success');
            }).catch(err => {
                log('Failed to copy seed: ' + err, 'error');
            });
        }

        function openImageFullscreen(src) {
            const overlay = document.createElement('div');
            overlay.style.cssText = `
                position: fixed; inset: 0; background: rgba(0,0,0,0.9);
                display: flex; align-items: center; justify-content: center;
                z-index: 10000; cursor: pointer;
            `;
            overlay.onclick = () => overlay.remove();

            const img = document.createElement('img');
            img.src = src;
            img.style.cssText = 'max-width: 90%; max-height: 90%; border-radius: 8px;';

            overlay.appendChild(img);
            document.body.appendChild(overlay);
        }

        function downloadImage(base64, prompt = '', seed = '') {
            const link = document.createElement('a');
            link.href = 'data:image/png;base64,' + base64;
            link.download = `unity-ai-image-${Date.now()}.png`;
            link.click();

            // also download metadata as txt if we have prompt info
            if (prompt) {
                setTimeout(() => {
                    downloadImageMetadata(prompt, seed);
                }, 500);
            }
        }

        function downloadImageMetadata(prompt, seed) {
            const metadata = `Unity AI Lab - Image Generation Metadata
=========================================
Generated: ${new Date().toISOString()}

PROMPT:
${prompt}

SEED: ${seed || 'random'}

=========================================
https://www.unityailab.com
`;
            const blob = new Blob([metadata], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `unity-ai-image-${Date.now()}-metadata.txt`;
            a.click();
            URL.revokeObjectURL(url);
        }

        function copyImageMetadata(prompt, seed) {
            const metadata = `Prompt: ${prompt}\nSeed: ${seed || 'random'}`;
            navigator.clipboard.writeText(metadata).then(() => {
                log('Image metadata copied to clipboard', 'success');
            }).catch(() => {
                log('Failed to copy metadata', 'error');
            });
        }

        function addSystemMessage(content) {
            const container = document.getElementById('chatMessages');
            const div = document.createElement('div');
            div.className = 'message assistant';
            div.innerHTML = `
                <div class="message-content" style="background: linear-gradient(135deg, rgba(220, 20, 60, 0.1), rgba(139, 0, 0, 0.1)); border-color: var(--accent-primary);">
                    ${escapeHtml(content)}
                </div>
            `;
            container.appendChild(div);
            scrollToBottom();
        }

        function renderMessage(role, content, timestamp, animate = true, isError = false) {
            const container = document.getElementById('chatMessages');
            const div = document.createElement('div');
            div.className = `message ${role}`;
            if (!animate) div.style.animation = 'none';

            // Process content for code blocks
            const processedContent = processMessageContent(content);

            const timeStr = timestamp ? new Date(timestamp).toLocaleTimeString() : '';

            // Get avatar based on role
            const avatar = role === 'assistant' ? getAIAvatarHTML() : getUserAvatarHTML();

            div.innerHTML = `
                <div class="message-wrapper">
                    ${avatar}
                    <div class="message-body">
                        <div class="message-content ${isError ? 'error' : ''}">
                            ${processedContent}
                        </div>
                        <div class="message-meta">
                            ${state.settings.showTimestamps ? `<span>${timeStr}</span>` : ''}
                            <div class="message-actions">
                                <button class="msg-action-btn" onclick="copyMessage(this)" title="Copy">📋</button>
                                ${role === 'assistant' ? `<button class="msg-action-btn" onclick="speakMessage(this)" title="Speak">🔊</button>` : ''}
                            </div>
                        </div>
                    </div>
                </div>
            `;

            container.appendChild(div);

            if (state.settings.autoScroll) {
                scrollToBottom();
            }
        }

        function processMessageContent(content) {
            // Escape HTML first
            let processed = escapeHtml(content);

            // Process code blocks
            processed = processed.replace(/```(\w+)?\n([\s\S]*?)```/g, (match, lang, code) => {
                const language = lang || 'code';
                const highlighted = highlightCode(code.trim(), language);
                return `
                    <div class="code-block">
                        <div class="code-header">
                            <span class="code-lang">${language}</span>
                            <button class="code-copy-btn" onclick="copyCode(this)">Copy</button>
                        </div>
                        <div class="code-content">${highlighted}</div>
                    </div>
                `;
            });

            // Process inline code
            processed = processed.replace(/`([^`]+)`/g, '<code style="background: var(--bg-void); padding: 0.2em 0.4em; border-radius: 3px; font-family: JetBrains Mono, monospace;">$1</code>');

            // Process line breaks
            processed = processed.replace(/\n/g, '<br>');

            return processed;
        }

        function highlightCode(code, lang) {
            // Basic syntax highlighting
            let highlighted = code;

            // Keywords
            const keywords = ['function', 'const', 'let', 'var', 'if', 'else', 'for', 'while', 'return', 'class', 'import', 'export', 'from', 'async', 'await', 'try', 'catch', 'def', 'print', 'self', 'True', 'False', 'None'];
            keywords.forEach(kw => {
                const regex = new RegExp(`\\b(${kw})\\b`, 'g');
                highlighted = highlighted.replace(regex, '<span class="keyword">$1</span>');
            });

            // Strings
            highlighted = highlighted.replace(/(["'`])(?:(?!\1)[^\\]|\\.)*\1/g, '<span class="string">$&</span>');

            // Numbers
            highlighted = highlighted.replace(/\b(\d+\.?\d*)\b/g, '<span class="number">$1</span>');

            // Comments
            highlighted = highlighted.replace(/(\/\/.*$|#.*$)/gm, '<span class="comment">$1</span>');

            return highlighted;
        }

        function showTyping() {
            const container = document.getElementById('chatMessages');
            const div = document.createElement('div');
            div.className = 'message assistant';
            div.id = 'typingIndicator';
            div.innerHTML = `
                <div class="typing-indicator">
                    <span></span><span></span><span></span>
                </div>
            `;
            container.appendChild(div);
            scrollToBottom();
        }

        function hideTyping() {
            const typing = document.getElementById('typingIndicator');
            if (typing) typing.remove();
        }

        function scrollToBottom() {
            const container = document.getElementById('chatMessages');
            // Get the last message and scroll it into view
            // scrollIntoView is more reliable across browsers than scrollTop
            const lastMessage = container.lastElementChild;
            if (lastMessage) {
                lastMessage.scrollIntoView({ behavior: 'smooth', block: 'end' });
            } else {
                // Fallback for empty container
                container.scrollTop = container.scrollHeight;
            }
        }

        // ==================== IMAGE GENERATION ====================
        async function loadImageModels() {
            try {
                const response = await apiCall('/api/image/models');
                const data = await response.json();

                const select = document.getElementById('imageModelSelect');
                select.innerHTML = '<option value="">-- Select an Image Model --</option>';

                const models = data.models || [];

                if (models.length === 0) {
                    select.innerHTML = '<option value="">No image models found</option>';
                    return;
                }

                models.forEach(model => {
                    const option = document.createElement('option');
                    option.value = model.id;
                    option.textContent = model.name;
                    if (model.id === data.current_model) {
                        option.selected = true;
                    }
                    select.appendChild(option);
                });

                if (data.current_model) {
                    document.getElementById('imageModelStatus').textContent =
                        `Loaded: ${models.find(m => m.id === data.current_model)?.name || data.current_model}`;
                } else if (models.length > 0) {
                    // Auto-load default image model if no model is loaded
                    const defaultModel = models.find(m =>
                        m.name.includes(DEFAULT_IMAGE_MODEL) || m.id.includes(DEFAULT_IMAGE_MODEL)
                    );
                    if (defaultModel) {
                        log(`Auto-selecting default image model: ${defaultModel.name}`, 'info');
                        select.value = defaultModel.id;
                        onImageModelSelect();
                    } else {
                        log('Default image model not found. Please select an image model.', 'warning');
                    }
                }
            } catch (error) {
                // server may be starting - log but don't show to user
                console.debug('loadImageModels failed (server starting?):', error.message);
            }
        }

        async function onImageModelSelect() {
            const select = document.getElementById('imageModelSelect');
            const modelId = select.value;

            if (!modelId) return;

            // show loading state
            select.disabled = true;
            select.style.opacity = '0.5';
            select.style.cursor = 'wait';

            // get model name for progress
            const modelName = select.options[select.selectedIndex]?.text || modelId;
            document.getElementById('imageModelStatus').textContent = 'Loading model...';
            document.getElementById('generateBtn').disabled = true;

            log(`⏳ Loading image model: ${modelName}`, 'info');
            log('→ Initializing Stable Diffusion pipeline...', 'info');

            const loadStart = Date.now();

            try {
                log('→ Loading model weights into VRAM...', 'info');
                const response = await apiCall('/api/image/load', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ model_id: modelId })
                });

                const data = await response.json();

                if (data.error) {
                    throw new Error(data.error);
                }

                const loadTime = ((Date.now() - loadStart) / 1000).toFixed(1);
                document.getElementById('imageModelStatus').textContent = `Loaded: ${data.model}`;
                document.getElementById('generateBtn').disabled = false;
                log(`✅ Image model loaded in ${loadTime}s: ${data.model}`, 'success');

                // if we don't have an avatar yet, generate one now
                if (!state.aiAvatar && !state.avatarGenerationPending) {
                    log('Image model ready - generating avatar...', 'info');
                    setTimeout(() => generateAISelfie(), 500);
                }
            } catch (error) {
                document.getElementById('imageModelStatus').textContent = 'Load failed';
                document.getElementById('generateBtn').disabled = true;
                log(`Image model failed: ${error.message}`, 'error');
            } finally {
                // restore dropdown state
                select.disabled = false;
                select.style.opacity = '';
                select.style.cursor = '';
            }
        }

        async function generateImage() {
            const prompt = document.getElementById('imagePrompt').value.trim();
            const negativePrompt = document.getElementById('negativePrompt').value.trim();
            const sizeStr = document.getElementById('imageSize').value;
            const steps = parseInt(document.getElementById('imageSteps').value);
            const cfg = parseFloat(document.getElementById('imageCfg').value);

            if (!prompt) {
                log('Please enter a prompt', 'warning');
                return;
            }

            // validate image size format - must be like "512x512"
            if (!sizeStr || !sizeStr.includes('x')) {
                log('Invalid image size format. Use WIDTHxHEIGHT (e.g., 512x512)', 'error');
                return;
            }
            const sizeParts = sizeStr.split('x').map(Number);
            if (sizeParts.length !== 2 || isNaN(sizeParts[0]) || isNaN(sizeParts[1])) {
                log('Invalid image size. Use numbers like 512x512', 'error');
                return;
            }
            const [width, height] = sizeParts;
            if (width < CONFIG.MIN_IMAGE_SIZE || height < CONFIG.MIN_IMAGE_SIZE || width > CONFIG.MAX_IMAGE_SIZE || height > CONFIG.MAX_IMAGE_SIZE) {
                log(`Image size must be between ${CONFIG.MIN_IMAGE_SIZE} and ${CONFIG.MAX_IMAGE_SIZE} pixels`, 'error');
                return;
            }

            // validate steps and cfg
            if (isNaN(steps) || steps < 1 || steps > 150) {
                log('Steps must be between 1 and 150', 'error');
                return;
            }
            if (isNaN(cfg) || cfg < 1 || cfg > 30) {
                log('CFG scale must be between 1 and 30', 'error');
                return;
            }

            const btn = document.getElementById('generateBtn');
            const preview = document.getElementById('imagePreview');

            btn.disabled = true;
            btn.textContent = '⏳ Generating...';
            preview.innerHTML = '<div class="image-placeholder">Generating image...</div>';

            log(`🎨 Starting image generation...`, 'info');
            log(`→ Prompt: "${prompt.substring(0, 60)}${prompt.length > 60 ? '...' : ''}"`, 'info');
            log(`→ Size: ${width}×${height} | Steps: ${steps} | CFG: ${cfg}`, 'info');

            const genStart = Date.now();

            try {
                log('→ Encoding prompts and preparing latents...', 'info');
                const response = await apiCall('/api/image/generate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        prompt,
                        negative_prompt: negativePrompt,
                        width,
                        height,
                        steps,
                        cfg_scale: cfg
                    })
                });

                const data = await response.json();

                if (data.error) {
                    throw new Error(data.error);
                }

                const totalTime = ((Date.now() - genStart) / 1000).toFixed(1);
                // Display the image
                preview.innerHTML = `<img src="data:image/png;base64,${data.image}" alt="Generated image">`;
                log(`✅ Image complete! ${totalTime}s total (server: ${data.time.toFixed(2)}s) | Seed: ${data.seed}`, 'success');

                // Also add to chat
                addImageToChat(prompt, data.image);

            } catch (error) {
                preview.innerHTML = `<div class="image-placeholder" style="color: #ef4444;">Error: ${error.message}</div>`;
                log(`Image generation failed: ${error.message}`, 'error');
            }

            btn.disabled = false;
            btn.textContent = '🎨 GENERATE IMAGE';
        }

        async function addImageToChat(prompt, base64Image) {
            const container = document.getElementById('chatMessages');
            const div = document.createElement('div');
            div.className = 'message assistant';

            // store large image in IndexedDB to save localStorage space
            const imageId = 'img_' + generateUUID();
            const imageSize = base64Image.length;

            // only store in IndexedDB if image is large (>100KB base64)
            if (imageSize > 100000) {
                await saveToIndexedDB(imageId, base64Image);
                log(`Large image (${Math.round(imageSize/1024)}KB) stored in IndexedDB`, 'info');
            }

            div.innerHTML = `
                <div class="message-content">
                    <p><em>Generated image: "${prompt}"</em></p>
                    <img src="data:image/png;base64,${base64Image}"
                         alt="${prompt}"
                         data-image-id="${imageId}"
                         style="max-width: 100%; border-radius: 8px; margin-top: 0.5rem; cursor: pointer;"
                         onclick="window.open(this.src, '_blank')">
                </div>
            `;
            container.appendChild(div);
            scrollToBottom();

            // add to session - store reference for large images, full data for small
            if (state.currentSession) {
                state.currentSession.messages.push({
                    role: 'assistant',
                    content: `[Generated image: ${prompt}]`,
                    timestamp: new Date().toISOString(),
                    imageId: imageSize > 100000 ? imageId : null,
                    imageData: imageSize <= 100000 ? base64Image : null,
                    imagePrompt: prompt
                });
                saveToStorage();
            }
        }

        // ==================== MEMORY SYSTEM ====================
        function updateMemoryDisplay() {
            const container = document.getElementById('memoryList');
            const countEl = document.getElementById('memoryCount');

            const charCount = state.memoryText.length;
            countEl.textContent = charCount > 0 ? `${charCount} chars` : 'Empty';

            if (!state.memoryText) {
                container.innerHTML = '<div style="padding: 2rem; text-align: center; color: var(--text-dim);">No memory set. Click EDIT to add information about yourself.</div>';
                return;
            }

            container.innerHTML = `
                <div class="memory-item" style="white-space: pre-wrap;">
                    <div class="memory-value">${escapeHtml(state.memoryText)}</div>
                </div>
            `;
        }

        function openAddMemory() {
            document.getElementById('memoryModal').classList.add('active');
            document.getElementById('memoryTextInput').value = state.memoryText;
            document.getElementById('memoryTextInput').focus();
        }

        function closeMemoryModal() {
            document.getElementById('memoryModal').classList.remove('active');
        }

        function saveMemoryText() {
            let text = document.getElementById('memoryTextInput').value.trim();

            // cap memory length
            if (text.length > CONFIG.MAX_MEMORY_LENGTH) {
                text = text.substring(0, CONFIG.MAX_MEMORY_LENGTH);
                log(`Memory truncated to ${CONFIG.MAX_MEMORY_LENGTH} chars`, 'warning');
            }

            state.memoryText = text;
            saveToStorage();
            syncMemoryToServer();  // sync to server
            updateMemoryDisplay();
            closeMemoryModal();
            log(text ? `Memory saved (${text.length} chars)` : 'Memory cleared', 'success');
        }

        // ==================== TTS ====================
        function toggleTTS() {
            // Check if TTS is supported before enabling
            if (!window.speechSynthesis) {
                log('TTS not available in this browser. Try Chrome, Edge, or Safari.', 'error');
                addSystemMessage('Text-to-speech is not supported in your browser. Try using Chrome, Edge, or Safari for TTS features.');
                return;
            }

            state.ttsEnabled = !state.ttsEnabled;
            const btn = document.getElementById('ttsToggle');
            btn.classList.toggle('active', state.ttsEnabled);
            document.getElementById('ttsEnabled').checked = state.ttsEnabled;
            log(`TTS ${state.ttsEnabled ? 'enabled' : 'disabled'}`, 'info');
        }

        function speakText(text) {
            // Fallback for browsers without Speech Synthesis
            if (!window.speechSynthesis || !speechSynth) {
                log('TTS not available - browser does not support Speech Synthesis API', 'warning');
                return;
            }

            // Cancel any ongoing speech
            speechSynth.cancel();

            // Clean text (remove code blocks, etc.)
            const cleanText = text
                .replace(/```[\s\S]*?```/g, 'Code block omitted.')
                .replace(/`[^`]+`/g, '')
                .replace(/\[.*?\]/g, '');

            try {
                const utterance = new SpeechSynthesisUtterance(cleanText);

                const voiceSelect = document.getElementById('ttsVoiceSelect');
                if (voices[voiceSelect.value]) {
                    utterance.voice = voices[voiceSelect.value];
                }

                utterance.volume = state.settings.volume;
                utterance.rate = state.settings.speechRate;
                utterance.pitch = state.settings.speechPitch;

                speechSynth.speak(utterance);
            } catch (error) {
                log('TTS error: ' + error.message, 'error');
            }
        }

        function speakMessage(btn) {
            const content = btn.closest('.message').querySelector('.message-content').textContent;
            speakText(content);
        }

        function stopSpeech() {
            if (speechSynth) {
                speechSynth.cancel();
            }
        }

        // update the header TTS button to show current voice name
        function updateTTSButtonText() {
            const btn = document.getElementById('ttsToggle');
            const voiceSelect = document.getElementById('ttsVoiceSelect');
            if (!btn || !voiceSelect) return;

            const voiceIndex = parseInt(voiceSelect.value);
            if (!isNaN(voiceIndex) && voices[voiceIndex]) {
                // extract short name (first word or before parenthesis)
                let voiceName = voices[voiceIndex].name;
                // strip "Microsoft" prefix and get first meaningful word
                voiceName = voiceName.replace(/^Microsoft\s+/i, '').split(/[\s(]/)[0];
                btn.innerHTML = `<span>🔊</span> TTS: ${voiceName}`;
            } else {
                btn.innerHTML = `<span>🔊</span> TTS`;
            }
        }

        // Preview the selected voice with a sample phrase
        function previewVoice() {
            if (!window.speechSynthesis) {
                log('TTS not supported in this browser', 'error');
                return;
            }
            const voiceSelect = document.getElementById('ttsVoiceSelect');
            const voiceIndex = parseInt(voiceSelect.value);

            if (isNaN(voiceIndex) || !voices[voiceIndex]) {
                log('No voice selected', 'warning');
                return;
            }

            // Stop any current speech
            speechSynth.cancel();

            const utterance = new SpeechSynthesisUtterance("Testing voice output.");
            utterance.voice = voices[voiceIndex];
            utterance.volume = state.settings.volume;
            utterance.rate = state.settings.speechRate;
            utterance.pitch = state.settings.speechPitch;

            speechSynth.speak(utterance);
            log(`Testing voice: ${voices[voiceIndex].name}`, 'info');
        }

        // ==================== SETTINGS ====================
        function openSettings() {
            document.getElementById('settingsModal').classList.add('active');
            loadSettingsValues();
        }

        function closeSettings() {
            document.getElementById('settingsModal').classList.remove('active');
        }

        function loadSettingsValues() {
            // Server URL
            document.getElementById('serverUrlInput').value = API_CONFIG.serverUrl || '';

            document.getElementById('temperatureSlider').value = state.settings.temperature * 100;
            document.getElementById('tempValue').textContent = state.settings.temperature.toFixed(1);

            document.getElementById('maxTokensInput').value = state.settings.maxTokens;

            document.getElementById('ttsEnabled').checked = state.ttsEnabled;

            document.getElementById('volumeSlider').value = state.settings.volume * 100;
            document.getElementById('volValue').textContent = Math.round(state.settings.volume * 100) + '%';

            document.getElementById('speechRateSlider').value = state.settings.speechRate * 100;
            document.getElementById('rateValue').textContent = Math.round(state.settings.speechRate * 100) + '%';

            document.getElementById('speechPitchSlider').value = (state.settings.speechPitch || 1.0) * 100;
            document.getElementById('pitchValue').textContent = Math.round((state.settings.speechPitch || 1.0) * 100) + '%';

            document.getElementById('autoScrollEnabled').checked = state.settings.autoScroll;
            document.getElementById('showTimestamps').checked = state.settings.showTimestamps;

            // Update trash list
            updateTrashList();

            // Load system prompt
            loadSystemPrompt();
        }

        async function loadSystemPrompt() {
            try {
                const response = await apiCall('/api/system-prompt');
                const data = await response.json();
                document.getElementById('systemPromptTextarea').value = data.system_prompt || '';
            } catch (error) {
                log('Failed to load system prompt', 'error');
            }
        }

        async function saveSettings() {
            // Save server URL first (may need to reconnect)
            const newServerUrl = document.getElementById('serverUrlInput').value.trim();
            if (newServerUrl !== API_CONFIG.serverUrl) {
                API_CONFIG.setServerUrl(newServerUrl);
                // Reconnect to new server
                await loadModels();
                await loadImageModels();
                await checkServerStatus();
            }

            // validate and clamp settings to safe ranges
            let temp = document.getElementById('temperatureSlider').value / 100;
            temp = Math.max(0, Math.min(1, temp));  // clamp 0-1
            state.settings.temperature = temp;

            let maxTok = parseInt(document.getElementById('maxTokensInput').value) || CONFIG.DEFAULT_MAX_TOKENS;
            maxTok = Math.max(1, Math.min(CONFIG.MAX_TOKENS_CEILING, maxTok));
            state.settings.maxTokens = maxTok;

            state.ttsEnabled = document.getElementById('ttsEnabled').checked;

            let vol = document.getElementById('volumeSlider').value / 100;
            vol = Math.max(0, Math.min(1, vol));  // clamp 0-1
            state.settings.volume = vol;

            let rate = document.getElementById('speechRateSlider').value / 100;
            rate = Math.max(0.1, Math.min(2, rate));  // clamp 0.1-2
            state.settings.speechRate = rate;

            let pitch = document.getElementById('speechPitchSlider').value / 100;
            pitch = Math.max(0.1, Math.min(2, pitch));  // clamp 0.1-2
            state.settings.speechPitch = pitch;

            state.settings.autoScroll = document.getElementById('autoScrollEnabled').checked;
            state.settings.showTimestamps = document.getElementById('showTimestamps').checked;

            saveToStorage();

            // Check if a new model was selected in settings
            const settingsModelSelect = document.getElementById('settingsModelSelect');
            const selectedModel = settingsModelSelect.value;
            if (selectedModel && selectedModel !== state.currentModel) {
                // Load the new model
                await loadModelFromSettings(selectedModel);
            }

            // Save system prompt
            const systemPrompt = document.getElementById('systemPromptTextarea').value;
            try {
                await apiCall('/api/system-prompt', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ system_prompt: systemPrompt })
                });
                log('Settings saved', 'success');
            } catch (error) {
                log('Failed to save system prompt', 'error');
            }

            closeSettings();
        }

        async function loadModelFromSettings(modelPath) {
            updateStatus('loading', 'Loading model...');

            try {
                const response = await apiCall('/api/models/load', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ model_path: modelPath })
                });

                const data = await response.json();

                if (!response.ok || data.error) {
                    throw new Error(data.error || `HTTP ${response.status}`);
                }

                state.currentModel = data.model_path;
                updateStatus('online', `Model: ${data.model_name}`);
                addSystemMessage(`Model loaded: ${data.model_name}`);

                // Update the header dropdown to match
                document.getElementById('modelSelect').value = data.model_path;
            } catch (error) {
                updateStatus('offline', 'Load failed');
                addSystemMessage(`Failed to load model: ${error.message}`);
            }
        }

        function updateSliderValue(slider, valueId, suffix = '') {
            const value = slider.id === 'temperatureSlider'
                ? (slider.value / 100).toFixed(1)
                : slider.value + suffix;
            document.getElementById(valueId).textContent = value;
        }

        // ==================== UI CONTROLS ====================
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('collapsed');
            sidebar.classList.toggle('open');
        }

        function toggleRightPanel() {
            const panel = document.getElementById('rightPanel');
            panel.classList.toggle('collapsed');
            panel.classList.toggle('open');
        }

        function switchPanelTab(tabName) {
            document.querySelectorAll('.panel-tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.panel-content').forEach(c => c.classList.remove('active'));

            document.querySelector(`.panel-tab[onclick="switchPanelTab('${tabName}')"]`).classList.add('active');
            document.getElementById(tabName + 'Tab').classList.add('active');
        }

        // Keyboard shortcut helper functions
        function toggleSessionsPanel() {
            const panel = document.getElementById('rightPanel');
            if (!panel.classList.contains('open')) {
                panel.classList.add('open');
                panel.classList.remove('collapsed');
            }
            switchPanelTab('sessions');
        }

        function toggleImagePanel() {
            const panel = document.getElementById('rightPanel');
            if (!panel.classList.contains('open')) {
                panel.classList.add('open');
                panel.classList.remove('collapsed');
            }
            switchPanelTab('generation');
        }

        function closeImagePanel() {
            const panel = document.getElementById('rightPanel');
            if (panel.classList.contains('open')) {
                panel.classList.remove('open');
                panel.classList.add('collapsed');
            }
        }

        // voice input state
        let voiceRecognition = null;
        let isListening = false;

        function toggleVoiceInput() {
            // check if browser supports speech recognition
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            if (!SpeechRecognition) {
                log('Voice input not supported in this browser. Try Chrome or Edge.', 'error');
                return;
            }

            const voiceBtn = document.querySelector('.input-btn[onclick="toggleVoiceInput()"]');

            if (isListening) {
                // stop listening
                if (voiceRecognition) {
                    voiceRecognition.stop();
                }
                isListening = false;
                voiceBtn.style.color = '';
                voiceBtn.title = 'Voice Input - Click to start';
                log('Voice input stopped', 'info');
                return;
            }

            // start listening
            voiceRecognition = new SpeechRecognition();
            voiceRecognition.continuous = false;
            voiceRecognition.interimResults = true;
            voiceRecognition.lang = 'en-US';

            voiceRecognition.onstart = () => {
                isListening = true;
                voiceBtn.style.color = '#ef4444';
                voiceBtn.title = 'Listening... Click to stop';
                log('Listening... speak now', 'info');
            };

            voiceRecognition.onresult = (event) => {
                const transcript = Array.from(event.results)
                    .map(result => result[0].transcript)
                    .join('');

                const messageInput = document.getElementById('messageInput');
                messageInput.value = transcript;
                autoResizeTextarea(messageInput);

                // if final result, stop and maybe send
                if (event.results[event.results.length - 1].isFinal) {
                    log('Got: ' + transcript.substring(0, 50) + '...', 'success');
                }
            };

            voiceRecognition.onerror = (event) => {
                log('Voice error: ' + event.error, 'error');
                isListening = false;
                voiceBtn.style.color = '';
            };

            voiceRecognition.onend = () => {
                isListening = false;
                voiceBtn.style.color = '';
                voiceBtn.title = 'Voice Input - Click to start';
            };

            voiceRecognition.start();
        }

        function autoResizeTextarea(textarea) {
            textarea.style.height = 'auto';
            textarea.style.height = Math.min(textarea.scrollHeight, CONFIG.MAX_TEXTAREA_HEIGHT) + 'px';
        }

        // textarea resize listener - wrapped in DOMContentLoaded so element exists
        document.addEventListener('DOMContentLoaded', () => {
            const messageInput = document.getElementById('messageInput');
            if (messageInput) {
                messageInput.addEventListener('input', function() {
                    autoResizeTextarea(this);
                });
            }
        });

        // ==================== UTILITY FUNCTIONS ====================
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function copyCode(btn) {
            const codeBlock = btn.closest('.code-block');
            const code = codeBlock.querySelector('.code-content').textContent;

            navigator.clipboard.writeText(code).then(() => {
                btn.textContent = 'Copied!';
                btn.classList.add('copied');
                setTimeout(() => {
                    btn.textContent = 'Copy';
                    btn.classList.remove('copied');
                }, 2000);
            });
        }

        function copyMessage(btn) {
            const content = btn.closest('.message').querySelector('.message-content').textContent;
            const originalText = btn.textContent;
            navigator.clipboard.writeText(content).then(() => {
                // Visual feedback - change to checkmark
                btn.textContent = '✓';
                btn.style.color = 'var(--success)';
                btn.disabled = true;
                setTimeout(() => {
                    btn.textContent = originalText;
                    btn.style.color = '';
                    btn.disabled = false;
                }, 1500);
                log('Message copied to clipboard', 'success');
            }).catch(() => {
                btn.textContent = '✗';
                btn.style.color = 'var(--error)';
                setTimeout(() => {
                    btn.textContent = originalText;
                    btn.style.color = '';
                }, 1500);
            });
        }

        // ==================== CONSOLE LOGGING ====================
        // store log entries for pagination
        const logEntries = [];
        let logCurrentPage = 0;
        const LOG_PAGE_SIZE = 30;

        function log(message, type = 'info') {
            const time = new Date().toLocaleTimeString();

            // store entry in array
            logEntries.push({ time, message, type });

            // trim old entries to prevent memory bloat
            while (logEntries.length > CONFIG.MAX_LOG_ENTRIES) {
                logEntries.shift();
            }

            // jump to last page when new log added
            logCurrentPage = Math.max(0, Math.ceil(logEntries.length / LOG_PAGE_SIZE) - 1);
            renderLogPage();
        }

        function renderLogPage() {
            const container = document.getElementById('consoleOutput');
            if (!container) return;

            const totalPages = Math.max(1, Math.ceil(logEntries.length / LOG_PAGE_SIZE));
            logCurrentPage = Math.max(0, Math.min(logCurrentPage, totalPages - 1));

            const start = logCurrentPage * LOG_PAGE_SIZE;
            const end = Math.min(start + LOG_PAGE_SIZE, logEntries.length);
            const pageEntries = logEntries.slice(start, end);

            container.innerHTML = pageEntries.map(entry =>
                `<div class="log-entry ${entry.type}"><span class="log-time">[${entry.time}]</span><span>${escapeHtml(entry.message)}</span></div>`
            ).join('');

            // update page info
            const pageInfo = document.getElementById('logPageInfo');
            if (pageInfo) {
                pageInfo.textContent = `${logCurrentPage + 1}/${totalPages} (${logEntries.length})`;
            }

            // scroll to bottom on last page
            if (logCurrentPage === totalPages - 1 && container.lastElementChild) {
                container.lastElementChild.scrollIntoView({ behavior: 'auto', block: 'end' });
            }
        }

        function logPagePrev() {
            if (logCurrentPage > 0) {
                logCurrentPage--;
                renderLogPage();
            }
        }

        function logPageNext() {
            const totalPages = Math.ceil(logEntries.length / LOG_PAGE_SIZE);
            if (logCurrentPage < totalPages - 1) {
                logCurrentPage++;
                renderLogPage();
            }
        }

        function exportLogs() {
            if (logEntries.length === 0) {
                log('No logs to export', 'warning');
                return;
            }

            // Export ALL logs from array, not just current page
            const logs = logEntries.map(entry => {
                const typeLabel = entry.type === 'error' ? 'ERROR' :
                                  entry.type === 'warning' ? 'WARN' :
                                  entry.type === 'success' ? 'OK' : 'INFO';
                return `[${entry.time}] [${typeLabel}] ${entry.message}`;
            }).join('\n');

            // Download as file
            const blob = new Blob([`Unity AI Lab - Console Log Export\n${'='.repeat(50)}\nExported: ${new Date().toISOString()}\nTotal Entries: ${logEntries.length}\n${'='.repeat(50)}\n\n${logs}`], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `unity-logs-${Date.now()}.txt`;
            a.click();
            URL.revokeObjectURL(url);

            log('Logs exported', 'success');
        }

        function clearLogs() {
            logEntries.length = 0;
            logCurrentPage = 0;
            renderLogPage();
            log('Console cleared', 'info');
        }

        // ==================== CLEAR CHAT ====================
        async function clearChat() {
            if (state.currentSession) {
                state.currentSession.messages = [];
                saveToStorage();
            }

            document.getElementById('chatMessages').innerHTML = '';
            addSystemMessage('Chat cleared.');

            try {
                await apiCall('/api/clear', { method: 'POST' });
                log('Chat history cleared', 'success');
            } catch (error) {
                log('Failed to clear server history', 'warning');
            }
        }

        // ==================== CLEAR CURRENT CHAT (Menu Button) ====================
        function clearCurrentChat() {
            showConfirmDialog(
                'Clear Current Chat',
                'Are you sure you want to clear the current chat? This will remove all messages in this session.',
                async () => {
                    if (state.currentSession) {
                        state.currentSession.messages = [];
                        saveToStorage();
                    }

                    document.getElementById('chatMessages').innerHTML = '';
                    addSystemMessage('Chat cleared.');

                    try {
                        await apiCall('/api/clear', { method: 'POST' });
                        log('Chat history cleared', 'success');
                    } catch (error) {
                        log('Failed to clear server history', 'warning');
                    }
                }
            );
        }

        // ==================== CLEAR ALL DATA ====================
        // Global abort controller for cancelling ongoing requests
        let globalAbortController = null;

        function clearAllData() {
            showConfirmDialog(
                'Clear All Data',
                'WARNING: This will permanently delete ALL your data including sessions, memories, settings, and AI avatar. This action cannot be undone!',
                async () => {
                    log('🗑️ CLEARING ALL DATA...', 'warning');

                    // STOP all ongoing processes first
                    log('Stopping all active processes...', 'info');

                    // Abort any ongoing API requests
                    if (globalAbortController) {
                        globalAbortController.abort();
                        globalAbortController = null;
                        log('Aborted ongoing API requests', 'info');
                    }

                    // Stop avatar generation if in progress
                    if (state.avatarGenerationPending) {
                        state.avatarGenerationPending = false;
                        log('Cancelled avatar generation', 'info');
                    }

                    // Stop any ongoing chat processing
                    if (state.isProcessing) {
                        state.isProcessing = false;
                        hideTyping();
                        log('Cancelled chat processing', 'info');
                    }

                    // Stop TTS if speaking
                    if (window.speechSynthesis && window.speechSynthesis.speaking) {
                        window.speechSynthesis.cancel();
                        log('Stopped text-to-speech', 'info');
                    }

                    // Stop polling
                    if (pollTimeoutId) {
                        clearTimeout(pollTimeoutId);
                        pollTimeoutId = null;
                        log('Stopped server polling', 'info');
                    }

                    // Clear all localStorage items related to Unity AI Lab
                    try {
                        localStorage.removeItem('unity_sessions');
                        localStorage.removeItem('unity_trashed_sessions');
                        localStorage.removeItem('unity_memory_text');
                        localStorage.removeItem('unity_settings');
                        localStorage.removeItem('unity_api_url');
                        localStorage.removeItem('unity_ai_avatar');
                        localStorage.removeItem('unity_avatar_generated');
                        localStorage.removeItem('unity_setup_complete');
                        log('Cleared localStorage', 'info');
                    } catch (e) {
                        // private browsing - no localStorage to clear
                    }

                    // Clear IndexedDB (avatar storage, images)
                    await clearIndexedDB();
                    log('Cleared IndexedDB', 'info');

                    // Reset state
                    state.sessions = [];
                    state.trashedSessions = [];
                    state.currentSession = null;
                    state.memoryText = '';
                    state.aiAvatar = null;
                    state.firstMessageSent = false;
                    state.settings = {
                        temperature: 0.7,
                        maxTokens: CONFIG.DEFAULT_MAX_TOKENS,
                        volume: 0.8,
                        speechRate: 1.0,
                        speechPitch: 1.0,
                        autoScroll: true,
                        showTimestamps: true
                    };
                    log('Reset application state', 'info');

                    // Clear UI
                    document.getElementById('chatMessages').innerHTML = '';
                    updateSessionList();
                    updateMemoryDisplay();
                    updateAllAIAvatars();

                    // Clear server-side history too
                    try {
                        await fetch(getApiUrl('/api/clear'), { method: 'POST' });
                        log('Cleared server-side chat history', 'info');
                    } catch (e) {
                        // server might not be running
                    }

                    log('✅ ALL DATA CLEARED SUCCESSFULLY', 'success');
                    log('Reloading page...', 'info');

                    // Reload page to show first-time setup wizard
                    setTimeout(() => {
                        location.reload();
                    }, 1000);
                }
            );
        }

        // ==================== CONFIRMATION DIALOG ====================
        function showConfirmDialog(title, message, onConfirm) {
            const dialog = document.createElement('div');
            dialog.className = 'confirm-dialog';
            dialog.innerHTML = `
                <div class="confirm-box">
                    <h3 class="confirm-title">${escapeHtml(title)}</h3>
                    <p class="confirm-message">${escapeHtml(message)}</p>
                    <div class="confirm-buttons">
                        <button class="modal-btn secondary" onclick="this.closest('.confirm-dialog').remove()">Cancel</button>
                        <button class="modal-btn primary" id="confirmBtn" style="background: linear-gradient(135deg, #8b0000, #dc143c);">Confirm</button>
                    </div>
                </div>
            `;

            document.body.appendChild(dialog);

            dialog.querySelector('#confirmBtn').onclick = () => {
                dialog.remove();
                onConfirm();
            };

            // Close on backdrop click
            dialog.onclick = (e) => {
                if (e.target === dialog) dialog.remove();
            };
        }

        // ==================== AI AVATAR (SELFIE) SYSTEM ====================
        // load avatar from IndexedDB (with localStorage migration)
        async function loadAvatarFromStorage() {
            try {
                // try IndexedDB first
                const idbAvatar = await loadFromIndexedDB('avatar');
                if (idbAvatar) {
                    state.aiAvatar = idbAvatar;
                    updateAllAIAvatars();
                    return;
                }

                // migrate from localStorage if exists
                const lsAvatar = localStorage.getItem('unity_ai_avatar');
                if (lsAvatar) {
                    state.aiAvatar = lsAvatar;
                    // migrate to IndexedDB
                    await saveToIndexedDB('avatar', lsAvatar);
                    // clean up localStorage
                    localStorage.removeItem('unity_ai_avatar');
                    log('Avatar migrated to IndexedDB', 'info');
                    updateAllAIAvatars();
                }
            } catch (e) {
                // fallback for private browsing
                state.aiAvatar = null;
            }
        }
        // initiate avatar load
        loadAvatarFromStorage();

        // Generate AI selfie using the image model
        async function generateAISelfie() {
            // Don't generate if already generating or no image model loaded
            if (state.avatarGenerationPending) return;

            const imageModelStatus = document.getElementById('imageModelStatus').textContent;
            // must start with "Loaded:" to confirm model is actually ready
            if (!imageModelStatus || !imageModelStatus.startsWith('Loaded:')) {
                log('Image model not loaded, skipping selfie generation', 'info');
                return;
            }

            state.avatarGenerationPending = true;
            log('🤳 Generating AI selfie...', 'info');

            // Simple selfie prompt - just a portrait photo
            const selfiePrompt = "selfie portrait photo, 25 year old woman, natural lighting, looking at camera, high quality, detailed face, sharp focus";
            const negativePrompt = "blurry, low quality, distorted, deformed, ugly, bad anatomy, text, watermark, cartoon, anime, illustration";

            const selfieStart = Date.now();

            // Create abort controller for this request so it can be cancelled
            globalAbortController = new AbortController();

            try {
                log('→ Generating 512×512 portrait (25 steps)...', 'info');
                const response = await apiCall('/api/image/generate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        prompt: selfiePrompt,
                        negative_prompt: negativePrompt,
                        width: 512,
                        height: 512,
                        steps: 25,
                        cfg_scale: 7
                    }),
                    signal: globalAbortController.signal
                });

                const data = await response.json();

                if (data.error) {
                    throw new Error(data.error);
                }

                const selfieTime = ((Date.now() - selfieStart) / 1000).toFixed(1);

                // Store the avatar in IndexedDB (much better for large images)
                state.aiAvatar = data.image;
                await saveToIndexedDB('avatar', data.image);
                await saveToIndexedDB('avatar_generated', Date.now());

                log(`✅ AI selfie complete in ${selfieTime}s! Looking good 💅`, 'success');

                // Update any existing AI avatars on the page
                updateAllAIAvatars();

            } catch (error) {
                // Check if this was an abort (user cleared data)
                if (error.name === 'AbortError') {
                    log('Avatar generation was cancelled', 'warning');
                } else {
                    log(`Failed to generate AI selfie: ${error.message}`, 'error');
                    addSystemMessage(`Avatar generation failed: ${error.message}. Using default avatar.`);
                }
            }

            globalAbortController = null;
            state.avatarGenerationPending = false;
        }

        // Update all AI avatars on the page with the current selfie
        function updateAllAIAvatars() {
            const avatars = document.querySelectorAll('.ai-avatar');
            avatars.forEach(avatar => {
                if (state.aiAvatar) {
                    avatar.innerHTML = `<img src="data:image/png;base64,${state.aiAvatar}" alt="AI">`;
                } else {
                    avatar.innerHTML = 'AI';
                }
            });
        }

        // Get avatar HTML for messages
        function getAIAvatarHTML() {
            if (state.aiAvatar) {
                return `<div class="ai-avatar"><img src="data:image/png;base64,${state.aiAvatar}" alt="AI"></div>`;
            }
            // Show loading spinner if avatar is being generated, otherwise show placeholder
            if (state.avatarGenerationPending) {
                return `<div class="ai-avatar ai-avatar-loading" title="Generating avatar...">⏳</div>`;
            }
            return `<div class="ai-avatar" title="Avatar not generated yet">AI</div>`;
        }

        function getUserAvatarHTML() {
            return `<div class="user-avatar">U</div>`;
        }

        // Check if we should regenerate avatar on page load (async now, uses IndexedDB)
        let avatarNeedsRefresh = false;
        async function checkAvatarRefreshAsync() {
            try {
                const lastGenerated = await loadFromIndexedDB('avatar_generated');
                if (!lastGenerated) {
                    avatarNeedsRefresh = true;
                    return true;
                }

                // Refresh every 24 hours on page reload
                const hoursSinceGenerated = (Date.now() - lastGenerated) / (1000 * 60 * 60);
                avatarNeedsRefresh = hoursSinceGenerated > 24;
                return avatarNeedsRefresh;
            } catch (e) {
                avatarNeedsRefresh = true;
                return true;
            }
        }
        // sync wrapper for existing code that expects sync result
        function checkAvatarRefresh() {
            return avatarNeedsRefresh;
        }
        // kick off the async check
        checkAvatarRefreshAsync();

        // ==================== TTS VOICE SELECTION - BRITISH UK FEMALE ====================
        function selectBritishFemaleVoice() {
            if (voices.length === 0) return;

            // Priority list of British female voices to look for
            const britishFemalePatterns = [
                /en-GB.*female/i,
                /en-GB/i,
                /en_GB/i,
                /british.*female/i,
                /uk.*female/i,
                /hazel/i,          // Common British voice name
                /kate/i,           // Common British voice name
                /serena/i,         // Common British voice name
                /emily/i,          // Sometimes British
                /fiona/i,          // Scottish/British
                /moira/i,          // Irish/British
                /Microsoft.*(Hazel|Susan|Libby)/i,  // Microsoft British voices
                /Google.*UK.*Female/i,
                /Amy/i,            // AWS Polly British voice
            ];

            let selectedIndex = -1;

            // First pass: Look for explicit British female voices
            for (const pattern of britishFemalePatterns) {
                for (let i = 0; i < voices.length; i++) {
                    const voice = voices[i];
                    const voiceInfo = `${voice.name} ${voice.lang}`;
                    if (pattern.test(voiceInfo)) {
                        // Prefer female voices
                        if (voice.name.toLowerCase().includes('female') ||
                            !voice.name.toLowerCase().includes('male')) {
                            selectedIndex = i;
                            break;
                        }
                    }
                }
                if (selectedIndex !== -1) break;
            }

            // Second pass: Look for any en-GB voice
            if (selectedIndex === -1) {
                for (let i = 0; i < voices.length; i++) {
                    if (voices[i].lang.startsWith('en-GB') || voices[i].lang.startsWith('en_GB')) {
                        selectedIndex = i;
                        break;
                    }
                }
            }

            // Set the voice if found
            if (selectedIndex !== -1) {
                const select = document.getElementById('ttsVoiceSelect');
                select.value = selectedIndex;
                log(`Selected British voice: ${voices[selectedIndex].name}`, 'success');
            } else {
                log('No British voice found, using default', 'warning');
            }
        }

