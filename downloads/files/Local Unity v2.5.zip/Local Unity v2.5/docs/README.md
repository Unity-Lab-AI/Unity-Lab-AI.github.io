# Unity AI Lab

Local AI Chat + Image Generation

**Website:** [www.unityailab.com](https://www.unityailab.com)
**Contact:** unityailabcontact@gmail.com
**Creators:** Hackall360, Sponge, GFourteen

---

## What Is This?

Unity AI Lab is a **completely local AI assistant** that runs on your computer. No internet required, no data sent anywhere, 100% private. You can:

- **Chat with AI** - Ask questions, get help, have conversations
- **Generate Images** - Describe what you want and the AI creates it
- **Save Sessions** - Keep your chat history organized
- **Customize** - Change the AI's personality with system prompts

Everything runs on YOUR hardware using YOUR graphics card. No subscriptions, no API keys, no cloud services.

---

## How It Works (Simple Version)

```
You type a message
        ↓
Browser sends it to the server (server.py)
        ↓
Server sends it to the AI model on your GPU
        ↓
AI thinks and generates a response
        ↓
Response appears in your browser
```

**The pieces:**
- `run.bat` - Starts everything with one double-click
- `server.py` - The "brain" that connects everything together
- `index.html` - The chat interface you see in your browser
- `download_models.py` - Automatically downloads all AI models
- `models/` - Where the AI brains live (auto-downloaded on first run)

---

## First Time Setup (What Happens)

When you run `run.bat` for the first time:

1. **Checks for Python** - Makes sure Python is installed
2. **Checks for GPU** - Looks for your NVIDIA graphics card
3. **Creates virtual environment** - A safe folder for all the AI stuff
4. **Downloads dependencies** (~5-10 minutes):
   - PyTorch (the AI engine)
   - llama-cpp-python (for text AI)
   - diffusers (for image AI)
5. **Downloads AI models** - Automatically downloads text and image models:
   - Text: Llama 3, Mistral, Phi-3, Qwen2 (GGUF format)
   - Image: DreamShaper, Realistic Vision, etc. (Diffusers format)
6. **Starts the server** - Gets everything running
7. **Opens your browser** - Shows you the chat interface

**After first run:** Steps 1-5 are skipped, starts in seconds.

---

## System Requirements

### Minimum
- **OS:** Windows 10/11 (64-bit)
- **GPU:** NVIDIA GTX 1060 6GB or better (CUDA required)
- **RAM:** 16 GB
- **Storage:** 20 GB free space
- **Python:** 3.10 or newer

### Recommended
- **GPU:** NVIDIA RTX 3060 12GB or better
- **RAM:** 32 GB
- **Storage:** 50 GB free space (for multiple models)

### Required Software
- [Python 3.10+](https://www.python.org/downloads/) (check "Add to PATH" during install)
- [NVIDIA GPU Drivers](https://www.nvidia.com/drivers) (latest version)
- [CUDA Toolkit](https://developer.nvidia.com/cuda-downloads) (12.x recommended)

---

## Quick Start

### Windows
Double-click `run.bat`

### Linux/Ubuntu Server
```bash
chmod +x start.sh
./start.sh --setup    # First time only - installs system deps
./start.sh            # Start the server
```

First run will:
1. Create virtual environment
2. Install PyTorch with CUDA
3. Install llama-cpp-python with CUDA
4. Install diffusers for image generation
5. Start server at http://localhost:8080
6. **Auto-open browser** (Windows only)

The `index.html` is served by the Flask server - it's the web UI for chatting with the AI and generating images.

---

## File Structure

```
TextImageLocalUnity/
├── run.bat           # Windows launcher
├── start.sh          # Linux/Ubuntu launcher
├── download_models.py # Auto-downloads models
├── server.py         # Flask server
├── index.html        # Web interface
├── data/             # Sessions, memories, system prompt
├── docs/             # Documentation
└── models/           # AI models (auto-downloaded)
```

---

## Adding Models

### Text Models (GGUF format)
Place `.gguf` files in `models/` folder:
```
models/
├── llama3/Llama-3.2-3B-Instruct-Q4_K_M.gguf
├── mistral/Mistral-7B-Instruct-v0.3.Q4_K_M.gguf
└── phi3/Phi-3-mini-4k-instruct-q4.gguf
```

### Image Models (Diffusers format)
Place model folders in `models/image/`:
```
models/image/
├── dreamshaper-8/
├── realistic-vision-v51/
└── epicrealism/
```

---

## Features

- Local LLM text generation (Phi-3, Llama 3, Mistral, Qwen2)
- Stable Diffusion image generation (DreamShaper, Realistic Vision)
- Session management with history
- Memory system for persistent context
- Customizable system prompt
- Voice output (TTS)
- Dark hacker-themed UI

---

See [README_TECHNICAL.md](README_TECHNICAL.md) for API reference.

**Built by Unity AI Lab**
