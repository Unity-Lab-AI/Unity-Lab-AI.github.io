# Unity AI Lab - Technical Reference

API documentation and technical details.

---

## System Requirements

### Hardware
| Component | Minimum | Recommended |
|-----------|---------|-------------|
| GPU | NVIDIA GTX 1060 6GB | NVIDIA RTX 3060 12GB+ |
| VRAM | 6 GB | 12 GB+ |
| RAM | 16 GB | 32 GB |
| Storage | 20 GB | 50 GB |
| CPU | Any modern 64-bit | 8+ cores |

### Software
| Software | Version | Notes |
|----------|---------|-------|
| Windows | 10/11 64-bit | Required |
| Python | 3.10+ | Add to PATH |
| NVIDIA Drivers | Latest | Required for CUDA |
| CUDA Toolkit | 12.x | Required for GPU acceleration |
| Visual C++ Build Tools | 2019+ | Required to build llama-cpp-python |

### VRAM Usage
| Model Type | VRAM Required |
|------------|---------------|
| 3B Text Model (Q4) | ~2 GB |
| 7B Text Model (Q4) | ~4 GB |
| SD 1.5 Image Model | ~4 GB |
| SDXL Image Model | ~8 GB |
| Both Text + Image | ~8-12 GB |

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      index.html                              │
│                   (Frontend - Browser)                       │
├─────────────────────────────────────────────────────────────┤
│                          ↕ HTTP                              │
├─────────────────────────────────────────────────────────────┤
│                      server.py                               │
│                   (Flask Backend)                            │
├──────────────────────┬──────────────────────────────────────┤
│   llama-cpp-python   │         diffusers                    │
│   (Text Generation)  │    (Image Generation)                │
├──────────────────────┴──────────────────────────────────────┤
│                    PyTorch + CUDA                            │
│                   (GPU Acceleration)                         │
└─────────────────────────────────────────────────────────────┘
```

---

## File Structure

```
TextImageLocalUnity/
├── run.bat           # Windows launcher
├── start.sh          # Linux/Ubuntu launcher
├── download_models.py # Model downloader
├── server.py         # Flask server
├── index.html        # Web interface
├── data/
│   ├── system_prompt.md
│   ├── memories.json
│   └── sessions.json
├── docs/
│   ├── README.md
│   └── README_TECHNICAL.md
└── models/
    ├── llama3/       # Text models (GGUF format)
    ├── mistral/
    ├── phi3/
    └── image/        # Image models (Diffusers format)
        ├── dreamshaper-8/
        └── realistic-vision-v51/
```

---

## Installation

### Automatic
**Windows:** Double-click `run.bat`

**Linux/Ubuntu:**
```bash
chmod +x start.sh
./start.sh --setup    # First time only
./start.sh            # Start server
```

First run takes 5-10 minutes to install dependencies. Server starts at http://localhost:8080

### Manual
```bash
python -m venv venv
venv\Scripts\activate
pip install flask flask-cors
pip install torch --index-url https://download.pytorch.org/whl/cu124
pip install diffusers transformers accelerate
pip install llama-cpp-python --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cu121
python server.py
```

---

## API Endpoints

### Chat
```http
POST /api/chat
{
    "message": "Hello",
    "session_id": "uuid",
    "memory_text": "context",
    "history": [{"role": "user", "content": "..."}]
}

Response: {
    "response": "AI text",
    "image": "base64 (if generated)",
    "image_seed": 12345,
    "time": 1.2,
    "tokens": {"prompt_tokens": 100, "completion_tokens": 50}
}
```

### Models
```http
GET  /api/models
POST /api/models/load     {"model_path": "./models/phi3/model.gguf"}
```

### Image
```http
GET  /api/image/models
POST /api/image/load      {"model_id": "dreamshaper-8"}
POST /api/image/generate  {"prompt": "...", "width": 512, "height": 512, "steps": 25}
GET  /api/image/status
```

### System
```http
GET  /api/status
GET  /api/cuda
GET  /api/system-prompt
POST /api/system-prompt   {"system_prompt": "..."}
```

### Memory & Sessions
```http
GET  /api/memories
POST /api/memories        {"memories": {"key": "value"}}
GET  /api/sessions
POST /api/sessions        {"name": "Chat 1"}
```

---

## Configuration

### Environment Variables
```bash
HOST=0.0.0.0
PORT=8080
MODELS_DIR=./models
GPU_LAYERS=-1        # -1 = all on GPU
TEMPERATURE=0.7
MAX_TOKENS=0         # 0 = unlimited
```

### Command Line
```bash
python server.py --host 0.0.0.0 --port 8080 --models-dir ./models
```

---

## GPU Verification

**Check CUDA status:**
```
GET /api/cuda
```

**Verify GPU usage in server logs:**
- Text: `load_tensors: layer X assigned to device CUDA0`
- Image: `Moving model to GPU (NVIDIA...)`

**If layers show CPU instead of CUDA:**
1. Delete venv folder
2. Run `run.bat` again to rebuild with CUDA

---

## Image Tool

The LLM generates images by including:
```
[Image: detailed prompt here]
```

Server parses this, runs Stable Diffusion, returns base64 image with response.

---

**Built by Unity AI Lab** | www.unityailab.com
