#!/usr/bin/env python3
# ═══════════════════════════════════════════════════════════════
# UNITY AI LAB - Model Downloader & Checker
# ═══════════════════════════════════════════════════════════════
# Version: 1.0 | Unity AI Lab
# Creators: Hackall360, Sponge, GFourteen
# ═══════════════════════════════════════════════════════════════
"""
Downloads default models and checks for manually added models.

Default Models:
  - Text: Mistral-7B-Instruct-v0.3.Q4_K_M.gguf (4.1GB)
  - Image: ponyRealism_v22MainVAE.safetensors (7.1GB SDXL)

Folder Structure:
  models/
  ├── mistral/
  │   └── Mistral-7B-Instruct-v0.3.Q4_K_M.gguf
  └── image/
      └── ponyRealism_V22/
          └── ponyRealism_v22MainVAE.safetensors

Any additional .gguf files in models/ or .safetensors in models/image/
will be automatically detected and available in the UI dropdowns.
"""

import os
import sys
import shutil
from pathlib import Path
from typing import Dict, List, Tuple
import urllib.request
import hashlib

# ═══════════════════════════════════════════════════════════════
# CONFIGURATION - Default Models
# ═══════════════════════════════════════════════════════════════

# these are the defaults that match index.html DEFAULT_TEXT_MODEL and DEFAULT_IMAGE_MODEL
DEFAULT_TEXT_MODEL = {
    "name": "Mistral-7B-Instruct-v0.3.Q4_K_M",
    "file": "Mistral-7B-Instruct-v0.3.Q4_K_M.gguf",
    "folder": "mistral",
    "url": "https://huggingface.co/MaziyarPanahi/Mistral-7B-Instruct-v0.3-GGUF/resolve/main/Mistral-7B-Instruct-v0.3.Q4_K_M.gguf",
    "size_gb": 4.1,
    "description": "Mistral 7B Instruct - excellent general purpose chat model"
}

DEFAULT_IMAGE_MODEL = {
    "name": "ponyRealism V2.2",
    "file": "ponyRealism_v22MainVAE.safetensors",
    "folder": "ponyRealism_V22",
    "url": "https://huggingface.co/Ine007/ponyRealism_v22MainVAE/resolve/main/ponyRealism_v22MainVAE.safetensors",
    "size_gb": 7.1,
    "description": "Photorealistic SDXL - great faces & skin"
}

# optional additional models users might want
OPTIONAL_TEXT_MODELS = {
    "llama3-3b": {
        "name": "Llama 3.2 3B Instruct",
        "file": "Llama-3.2-3B-Instruct-Q4_K_M.gguf",
        "folder": "llama3",
        "url": "https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf",
        "size_gb": 2.0,
        "description": "Meta's latest small model - fast and efficient"
    },
    "qwen25-7b": {
        "name": "Qwen 2.5 7B Instruct",
        "file": "Qwen2.5-7B-Instruct-Q4_K_M.gguf",
        "folder": "qwen25",
        "url": "https://huggingface.co/bartowski/Qwen2.5-7B-Instruct-GGUF/resolve/main/Qwen2.5-7B-Instruct-Q4_K_M.gguf",
        "size_gb": 4.7,
        "description": "Alibaba's top model - great multilingual & coding"
    },
    "phi3-mini": {
        "name": "Phi-3.5 Mini Instruct",
        "file": "Phi-3.5-mini-instruct-Q4_K_M.gguf",
        "folder": "phi3",
        "url": "https://huggingface.co/bartowski/Phi-3.5-mini-instruct-GGUF/resolve/main/Phi-3.5-mini-instruct-Q4_K_M.gguf",
        "size_gb": 2.4,
        "description": "Microsoft's efficient small model"
    },
    "llama31-8b": {
        "name": "Llama 3.1 8B Instruct",
        "file": "Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf",
        "folder": "llama31",
        "url": "https://huggingface.co/bartowski/Meta-Llama-3.1-8B-Instruct-GGUF/resolve/main/Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf",
        "size_gb": 4.9,
        "description": "Meta's powerful 8B model - excellent quality"
    }
}

OPTIONAL_IMAGE_MODELS = {
    "realvisxl-v5": {
        "name": "RealVisXL V5.0",
        "file": "RealVisXL_V5.0_fp16.safetensors",
        "folder": "realvisxl_v5",
        "url": "https://huggingface.co/SG161222/RealVisXL_V5.0/resolve/main/RealVisXL_V5.0_fp16.safetensors",
        "size_gb": 6.9,
        "description": "Top-rated photorealistic model"
    },
    "juggernaut-xl": {
        "name": "Juggernaut XL v9",
        "file": "Juggernaut-XL_v9_RunDiffusionPhoto_v2.safetensors",
        "folder": "juggernaut_xl",
        "url": "https://huggingface.co/RunDiffusion/Juggernaut-XL-v9/resolve/main/Juggernaut-XL_v9_RunDiffusionPhoto_v2.safetensors",
        "size_gb": 6.9,
        "description": "Most downloaded SDXL model - versatile"
    },
    "dreamshaper-xl": {
        "name": "DreamShaper XL v2 Turbo",
        "file": "DreamShaperXL_Turbo_v2.safetensors",
        "folder": "dreamshaper_xl",
        "url": "https://huggingface.co/Lykon/dreamshaper-xl-v2-turbo/resolve/main/DreamShaperXL_Turbo_v2.safetensors",
        "size_gb": 6.9,
        "description": "Fast artistic/creative generations"
    },
    "epicrealism-xl": {
        "name": "epiCRealism XL v5",
        "file": "epicrealismXL_v5Ultimate.safetensors",
        "folder": "epicrealism_xl",
        "url": "https://huggingface.co/ronniereagan/epic-realism-xl-ultimate/resolve/main/epicrealismXL_v5Ultimate.safetensors",
        "size_gb": 6.9,
        "description": "Ultra realistic photography style"
    }
}

# ═══════════════════════════════════════════════════════════════
# PATHS
# ═══════════════════════════════════════════════════════════════

SCRIPT_DIR = Path(__file__).parent.resolve()  # src/
ROOT_DIR = SCRIPT_DIR.parent  # project root
MODELS_DIR = ROOT_DIR / "models"
IMAGE_MODELS_DIR = MODELS_DIR / "image"


# ═══════════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════════

def format_size(bytes_size: int) -> str:
    """format bytes to human readable"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if bytes_size < 1024:
            return f"{bytes_size:.2f} {unit}"
        bytes_size /= 1024
    return f"{bytes_size:.2f} TB"


def download_with_progress(url: str, dest: Path, description: str) -> bool:
    """download a file with progress bar"""
    print(f"\n  ⏳ Downloading {description}...")
    print(f"     URL: {url[:80]}{'...' if len(url) > 80 else ''}")
    print(f"     Dest: {dest}")

    try:
        # create parent directory
        dest.parent.mkdir(parents=True, exist_ok=True)

        # temp file for download
        temp_dest = dest.with_suffix(dest.suffix + '.tmp')

        # setup request with headers (some hosts need user-agent)
        request = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })

        with urllib.request.urlopen(request, timeout=30) as response:
            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0
            block_size = 1024 * 1024  # 1MB blocks

            print(f"     Size: {format_size(total_size) if total_size else 'Unknown'}")

            with open(temp_dest, 'wb') as f:
                while True:
                    block = response.read(block_size)
                    if not block:
                        break
                    f.write(block)
                    downloaded += len(block)

                    if total_size:
                        percent = (downloaded / total_size) * 100
                        bar_len = 30
                        filled = int(bar_len * downloaded / total_size)
                        bar = '█' * filled + '░' * (bar_len - filled)
                        print(f"\r     [{bar}] {percent:.1f}% ({format_size(downloaded)}/{format_size(total_size)})", end='', flush=True)
                    else:
                        print(f"\r     Downloaded: {format_size(downloaded)}", end='', flush=True)

            print()  # newline after progress

            # move temp to final
            shutil.move(str(temp_dest), str(dest))
            print(f"  ✅ {description} downloaded successfully!")
            return True

    except KeyboardInterrupt:
        print("\n  ⚠️  Download cancelled by user")
        if temp_dest.exists():
            temp_dest.unlink()
        return False
    except Exception as e:
        print(f"\n  ❌ Download failed: {e}")
        if temp_dest.exists():
            temp_dest.unlink()
        return False


# ═══════════════════════════════════════════════════════════════
# SCANNER FUNCTIONS
# ═══════════════════════════════════════════════════════════════

def scan_text_models() -> List[Dict]:
    """scan for all .gguf text models in models/ folder"""
    models = []

    if not MODELS_DIR.exists():
        return models

    # find all .gguf files recursively
    for gguf_file in MODELS_DIR.rglob("*.gguf"):
        # skip files in the image folder
        if "image" in gguf_file.parts:
            continue

        size_gb = gguf_file.stat().st_size / (1024**3)
        models.append({
            "name": gguf_file.stem,
            "file": gguf_file.name,
            "path": str(gguf_file),
            "size_gb": round(size_gb, 2),
            "folder": gguf_file.parent.name
        })

    return models


def scan_image_models() -> List[Dict]:
    """scan for all image models in models/image/ folder"""
    models = []

    if not IMAGE_MODELS_DIR.exists():
        return models

    for item in IMAGE_MODELS_DIR.iterdir():
        if not item.is_dir():
            continue

        # check for diffusers format
        if (item / "model_index.json").exists():
            models.append({
                "name": item.name,
                "type": "diffusers",
                "path": str(item),
                "folder": item.name
            })
            continue

        # check for safetensors
        safetensors = list(item.glob("*.safetensors"))
        if safetensors:
            main_file = safetensors[0]
            size_gb = main_file.stat().st_size / (1024**3)
            models.append({
                "name": item.name,
                "file": main_file.name,
                "type": "safetensors",
                "path": str(main_file),
                "size_gb": round(size_gb, 2),
                "folder": item.name
            })

    return models


def check_default_text_model() -> Tuple[bool, Path]:
    """check if default text model exists"""
    expected_path = MODELS_DIR / DEFAULT_TEXT_MODEL["folder"] / DEFAULT_TEXT_MODEL["file"]
    return expected_path.exists(), expected_path


def check_default_image_model() -> Tuple[bool, Path]:
    """check if default image model exists"""
    expected_path = IMAGE_MODELS_DIR / DEFAULT_IMAGE_MODEL["folder"] / DEFAULT_IMAGE_MODEL["file"]
    return expected_path.exists(), expected_path


# ═══════════════════════════════════════════════════════════════
# MAIN FUNCTIONS
# ═══════════════════════════════════════════════════════════════

def print_banner():
    """print the Unity AI Lab banner"""
    print()
    print("  ╔═══════════════════════════════════════════════════════════════╗")
    print("  ║           UNITY AI LAB - Model Downloader & Checker           ║")
    print("  ║         https://www.unityailab.com                            ║")
    print("  ╚═══════════════════════════════════════════════════════════════╝")
    print()


def show_status():
    """show current model status"""
    print("  ═══════════════════════════════════════════════════════════════")
    print("  📊 CURRENT MODEL STATUS")
    print("  ═══════════════════════════════════════════════════════════════")

    # check directories exist
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    IMAGE_MODELS_DIR.mkdir(parents=True, exist_ok=True)

    # scan existing models
    text_models = scan_text_models()
    image_models = scan_image_models()

    # check defaults
    text_default_exists, text_default_path = check_default_text_model()
    image_default_exists, image_default_path = check_default_image_model()

    print()
    print(f"  📁 Models Directory: {MODELS_DIR}")
    print(f"  📁 Image Models Directory: {IMAGE_MODELS_DIR}")
    print()

    # text models
    print("  ─────────────────────────────────────────────────────────────────")
    print("  📝 TEXT MODELS (.gguf)")
    print("  ─────────────────────────────────────────────────────────────────")

    if text_default_exists:
        print(f"  ✅ DEFAULT: {DEFAULT_TEXT_MODEL['name']} ({DEFAULT_TEXT_MODEL['size_gb']}GB)")
    else:
        print(f"  ❌ DEFAULT MISSING: {DEFAULT_TEXT_MODEL['name']}")
        print(f"     Expected at: {text_default_path}")

    if text_models:
        print(f"\n  Found {len(text_models)} text model(s):")
        for m in text_models:
            is_default = m['name'] == DEFAULT_TEXT_MODEL['name'].replace('.gguf', '')
            marker = "⭐" if is_default else "  "
            print(f"  {marker} {m['name']} ({m['size_gb']}GB) - {m['folder']}/")
    else:
        print("\n  ⚠️  No text models found!")

    print()

    # image models
    print("  ─────────────────────────────────────────────────────────────────")
    print("  🎨 IMAGE MODELS (.safetensors / diffusers)")
    print("  ─────────────────────────────────────────────────────────────────")

    if image_default_exists:
        print(f"  ✅ DEFAULT: {DEFAULT_IMAGE_MODEL['name']} ({DEFAULT_IMAGE_MODEL['size_gb']}GB)")
    else:
        print(f"  ❌ DEFAULT MISSING: {DEFAULT_IMAGE_MODEL['name']}")
        print(f"     Expected at: {image_default_path}")

    if image_models:
        print(f"\n  Found {len(image_models)} image model(s):")
        for m in image_models:
            is_default = m['name'] == DEFAULT_IMAGE_MODEL['name']
            marker = "⭐" if is_default else "  "
            size_str = f"({m.get('size_gb', '?')}GB)" if 'size_gb' in m else f"({m['type']})"
            print(f"  {marker} {m['name']} {size_str} - {m['folder']}/")
    else:
        print("\n  ⚠️  No image models found!")

    print()

    return text_default_exists, image_default_exists, text_models, image_models


def download_defaults(force: bool = False):
    """download default models if missing"""
    text_exists, image_exists, _, _ = check_default_text_model()[0], check_default_image_model()[0], None, None
    text_exists, text_path = check_default_text_model()
    image_exists, image_path = check_default_image_model()

    print("  ═══════════════════════════════════════════════════════════════")
    print("  📥 DOWNLOADING DEFAULT MODELS")
    print("  ═══════════════════════════════════════════════════════════════")

    # download text model
    if not text_exists or force:
        print(f"\n  📝 Text Model: {DEFAULT_TEXT_MODEL['name']}")
        print(f"     {DEFAULT_TEXT_MODEL['description']}")
        download_with_progress(
            DEFAULT_TEXT_MODEL['url'],
            text_path,
            f"{DEFAULT_TEXT_MODEL['name']} ({DEFAULT_TEXT_MODEL['size_gb']}GB)"
        )
    else:
        print(f"\n  ✅ Text model already exists: {DEFAULT_TEXT_MODEL['name']}")

    # download image model
    if not image_exists or force:
        print(f"\n  🎨 Image Model: {DEFAULT_IMAGE_MODEL['name']}")
        print(f"     {DEFAULT_IMAGE_MODEL['description']}")
        print("     ⚠️  Note: CivitAI downloads may require manual download if this fails")
        download_with_progress(
            DEFAULT_IMAGE_MODEL['url'],
            image_path,
            f"{DEFAULT_IMAGE_MODEL['name']} ({DEFAULT_IMAGE_MODEL['size_gb']}GB)"
        )
    else:
        print(f"\n  ✅ Image model already exists: {DEFAULT_IMAGE_MODEL['name']}")


def interactive_menu():
    """interactive menu for model management"""
    while True:
        print()
        print("  ═══════════════════════════════════════════════════════════════")
        print("  🎮 WHAT DO YOU WANT TO DO?")
        print("  ═══════════════════════════════════════════════════════════════")
        print()
        print("  [1] Check model status")
        print("  [2] Download default models (Mistral + ponyRealism V2.2)")
        print("  [3] Download optional text model")
        print("  [4] Show folder structure")
        print("  [5] Exit")
        print()

        choice = input("  Enter choice (1-5): ").strip()

        if choice == '1':
            show_status()
        elif choice == '2':
            download_defaults()
        elif choice == '3':
            print("\n  Available optional text models:")
            for key, model in OPTIONAL_TEXT_MODELS.items():
                print(f"    [{key}] {model['name']} ({model['size_gb']}GB) - {model['description']}")

            model_choice = input("\n  Enter model key (or 'back'): ").strip().lower()
            if model_choice in OPTIONAL_TEXT_MODELS:
                model = OPTIONAL_TEXT_MODELS[model_choice]
                model_path = MODELS_DIR / model['folder'] / model['file']
                if model_path.exists():
                    print(f"  ✅ {model['name']} already exists")
                else:
                    download_with_progress(model['url'], model_path, f"{model['name']} ({model['size_gb']}GB)")
        elif choice == '4':
            print("\n  Expected folder structure:")
            print("  ")
            print("  models/")
            print("  ├── mistral/")
            print("  │   └── Mistral-7B-Instruct-v0.3.Q4_K_M.gguf  (default text)")
            print("  ├── [other-model]/")
            print("  │   └── [any-model].gguf                      (auto-detected)")
            print("  └── image/")
            print("      ├── ponyRealism_V22/")
            print("      │   └── ponyRealism_V22.safetensors       (default image)")
            print("      └── [other-model]/")
            print("          └── [any-model].safetensors           (auto-detected)")
            print()
            print("  💡 TIP: Just drop model files in the right folders and restart the server!")
        elif choice == '5':
            print("\n  👋 Goodbye!")
            break
        else:
            print("  ❌ Invalid choice")


def main():
    """main entry point"""
    print_banner()

    # parse args
    args = sys.argv[1:]

    if '--check' in args or '-c' in args:
        # just show status
        text_ok, image_ok, text_models, image_models = show_status()
        sys.exit(0 if (text_ok and image_ok) else 1)

    elif '--download' in args or '-d' in args:
        # download defaults non-interactively
        show_status()
        download_defaults()
        print("\n  ✅ Done!")
        sys.exit(0)

    elif '--force' in args or '-f' in args:
        # force re-download
        show_status()
        download_defaults(force=True)
        print("\n  ✅ Done!")
        sys.exit(0)

    elif '--help' in args or '-h' in args:
        print("  Usage: python download_models.py [options]")
        print()
        print("  Options:")
        print("    --check, -c     Check model status and exit")
        print("    --download, -d  Download missing default models")
        print("    --force, -f     Force re-download all default models")
        print("    --help, -h      Show this help message")
        print()
        print("  No options: Interactive menu")
        sys.exit(0)

    else:
        # interactive mode
        show_status()
        interactive_menu()


if __name__ == "__main__":
    main()
