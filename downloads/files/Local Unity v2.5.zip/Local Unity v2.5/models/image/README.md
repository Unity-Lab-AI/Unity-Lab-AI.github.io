# Image Models Directory

This folder stores downloaded AI image generation models used by Local Unity.

## Important Notes

- **Models are downloaded automatically** when you first run the application
- **Models are NOT stored in Git** - they are too large and should be downloaded locally
- This README.md file exists to ensure the `models/image/` folder is tracked by Git

## Folder Structure

Image models go in subfolders:
```
models/image/
├── ponyRealism_V22/
│   └── ponyRealism_V22.safetensors    (default)
├── dreamshaper_xl/
│   └── dreamshaperXL.safetensors
└── [your-model]/
    └── [model-file].safetensors
```

## Supported Model Types

- Stable Diffusion 1.5 models
- SDXL models
- ControlNet models
- LoRA adapters
- VAE models

## Supported Formats

- `.safetensors` - Safe tensor format (recommended)
- `.ckpt` - Checkpoint files
- `.bin` - Binary model files
- `.pt` / `.pth` - PyTorch models

## Downloading Models

Models will be automatically downloaded when you start the application. You can also manually trigger the download by running:

```bash
python download_models.py
```

## Default Model

The default image model is **ponyRealism_V22** - a 6.5GB SDXL photorealistic model.
