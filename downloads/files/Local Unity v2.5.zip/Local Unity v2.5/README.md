# Unity AI Lab

Local AI Chat + Image Generation

**Website:** [www.unityailab.com](https://www.unityailab.com)
**Contact:** unityailabcontact@gmail.com
**Creators:** Hackall360, Sponge, GFourteen

---

## What Is This?

Unity AI Lab is a **completely local AI assistant** that runs on your computer. No internet required, no data sent anywhere, 100% private. You can:

- **Chat with AI** - Ask questions, get help, have conversations
- **Generate Images** - Describe what you want and the AI creates it
- **Save Sessions** - Keep your chat history organized
- **Customize** - Change the AI's personality with system prompts

Everything runs on YOUR hardware using YOUR graphics card. No subscriptions, no API keys, no cloud services.

---

## How It Works (Simple Version)

```
You type a message
        ↓
Browser sends it to the server (server.py)
        ↓
Server sends it to the AI model on your GPU
        ↓
AI thinks and generates a response
        ↓
Response appears in your browser
```

**The pieces:**
- `run.bat` - Starts everything with one double-click
- `src/server.py` - The "brain" that connects everything together
- `index.html` - The chat interface you see in your browser
- `src/download_models.py` - Automatically downloads all AI models
- `models/` - Where the AI brains live (auto-downloaded on first run) add more from https://civitai.com/ or https://huggingface.co/

---

## First Time Setup (What Happens)

When you run `run.bat` for the first time:

1. **Checks for Python** - Makes sure Python is installed
2. **Checks for GPU** - Looks for your NVIDIA graphics card
3. **Creates virtual environment** - A safe folder for all the AI stuff
4. **Downloads dependencies** (~5-10 minutes):
   - PyTorch (the AI engine)
   - llama-cpp-python (for text AI)
   - diffusers (for image AI)
5. **Downloads AI models** - Automatically downloads text and image models:
   - Text: Llama 3, Mistral, Phi-3, Qwen2 (GGUF format)
   - Image: DreamShaper, Realistic Vision, etc. (Diffusers format)
6. **Starts the server** - Gets everything running
7. **Opens your browser** - Shows you the chat interface

**After first run:** Steps 1-5 are skipped, starts in seconds.

---

## System Requirements

### Minimum
- **OS:** Windows 10/11 (64-bit)
- **GPU:** NVIDIA GTX 1060 6GB or better (CUDA required)
- **RAM:** 16 GB
- **Storage:** 20 GB free space
- **Python:** 3.10 or newer

### Recommended
- **GPU:** NVIDIA RTX 3060 12GB or better
- **RAM:** 32 GB
- **Storage:** 50 GB free space (for multiple models)

### Required Software
- [Python 3.10+](https://www.python.org/downloads/) (check "Add to PATH" during install)
- [NVIDIA GPU Drivers](https://www.nvidia.com/drivers) (latest version)
- [CUDA Toolkit](https://developer.nvidia.com/cuda-downloads) (12.x recommended)

---

## Quick Start

### Windows
Double-click `run.bat`

### Linux/Ubuntu Server
```bash
chmod +x start.sh
./start.sh --setup    # First time only - installs system deps
./start.sh            # Start the server
```

First run will:
1. Create virtual environment
2. Install PyTorch with CUDA
3. Install llama-cpp-python with CUDA
4. Install diffusers for image generation
5. Start server at http://localhost:8080
6. **Auto-open browser** (Windows only)

The `index.html` is served by the Flask server - it's the web UI for chatting with the AI and generating images.

---

## File Structure

```
Unity AI Lab/
├── index.html              # Web interface (root)
├── run.bat                 # Windows launcher (root)
├── start.sh                # Linux/Ubuntu launcher (root)
│
├── src/                    # Python source code
│   ├── server.py           # Flask server - the brain
│   └── download_models.py  # Model downloader
│
├── static/                 # Frontend assets
│   ├── css/
│   │   └── styles.css      # Dark hacker theme
│   ├── js/
│   │   └── app.js          # Frontend JavaScript
│   └── fonts/
│       ├── TrajanPro-Regular.woff
│       └── TrajanPro-Bold.woff
│
├── models/                 # AI models (auto-downloaded)
│   ├── mistral/            # Text model folder
│   │   └── Mistral-7B-Instruct-v0.3.Q4_K_M.gguf
│   └── image/              # Image models
│       └── ponyRealism_V22/
│           └── ponyRealism_v22MainVAE.safetensors
│
├── data/                   # User data (auto-created)
│   ├── memories.json       # AI memories
│   ├── sessions.json       # Chat sessions
│   └── system_prompt.md    # AI personality
│
└── docs/                   # Documentation
    ├── README.md
    └── README_TECHNICAL.md
```

---

## Adding Models

### Text Models (GGUF format)
Download `.gguf` files from [Hugging Face](https://huggingface.co/models?search=gguf) and place in `models/[model_name]/`:
```
models/
├── mistral/
│   └── Mistral-7B-Instruct-v0.3.Q4_K_M.gguf
├── llama3/
│   └── Llama-3.2-3B-Instruct-Q4_K_M.gguf
└── qwen25/
    └── Qwen2.5-7B-Instruct-Q4_K_M.gguf
```

### Image Models (Safetensors format)
Download `.safetensors` files from [CivitAI](https://civitai.com/models?types=Checkpoint) or [Hugging Face](https://huggingface.co/models?pipeline_tag=text-to-image) and place in `models/image/[model_name]/`:
```
models/image/
├── ponyRealism_V22/
│   └── ponyRealism_v22MainVAE.safetensors
├── realvisxl_v5/
│   └── RealVisXL_V5.0_fp16.safetensors
└── juggernaut_xl/
    └── Juggernaut-XL_v9_RunDiffusionPhoto_v2.safetensors
```

---

## Features

- **Local LLM Text Generation** - Mistral, Llama 3, Qwen 2.5, Phi-3
- **SDXL Image Generation** - ponyRealism, RealVisXL, Juggernaut XL, DreamShaper
- **Model Download Wizard** - Select and download models on first run
- **Session Management** - Save and organize chat history
- **Memory System** - AI remembers context across sessions
- **Customizable Personality** - Edit system prompt in data/system_prompt.md
- **Voice Output (TTS)** - AI can speak responses
- **Dark Gothic UI** - Hacker-themed interface

---

## Default Models

**Text (GGUF):**
- Mistral 7B Instruct v0.3 (4.1 GB) - Recommended

**Image (SDXL Safetensors):**
- ponyRealism V2.2 (7.1 GB) - Photorealistic, great faces

**Optional Models Available in Wizard:**
- Llama 3.2 3B, Llama 3.1 8B, Qwen 2.5 7B, Phi-3.5 Mini
- RealVisXL V5.0, Juggernaut XL v9, DreamShaper XL, epiCRealism XL

---

See [docs/README_TECHNICAL.md](docs/README_TECHNICAL.md) for API reference.

**Built by Unity AI Lab**
