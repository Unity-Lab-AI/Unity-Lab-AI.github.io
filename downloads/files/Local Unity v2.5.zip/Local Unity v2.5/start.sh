#!/bin/bash
# Unity AI Lab - Linux/Ubuntu Launcher
# Usage: ./start.sh [--setup|--fix-gpu|--fix-llm|--cleanup]

set -e

echo ""
echo "========================================================"
echo "     UNITY AI LAB - Local AI Chat + Image Generation"
echo "     www.unityailab.com"
echo "========================================================"
echo ""

ACTION="${1:-run}"

show_help() {
    echo "Usage: ./start.sh [option]"
    echo ""
    echo "Options:"
    echo "  --setup      First-time setup (install system deps)"
    echo "  --fix-gpu    Fix PyTorch CUDA for image generation"
    echo "  --fix-llm    Fix llama-cpp-python CUDA for text generation"
    echo "  --cleanup    Clean caches and free disk space"
    echo "  --help       Show this help message"
    echo ""
    echo "No option = Start the server normally"
    echo ""
}

# ==================== HELP ====================
if [[ "$ACTION" == "--help" || "$ACTION" == "-h" ]]; then
    show_help
    exit 0
fi

# ==================== FIRST-TIME SETUP ====================
if [[ "$ACTION" == "--setup" ]]; then
    echo "[SETUP] Installing system dependencies..."
    echo ""

    # Detect package manager
    if command -v apt &> /dev/null; then
        sudo apt update
        sudo apt install -y python3 python3-pip python3-venv build-essential
    elif command -v dnf &> /dev/null; then
        sudo dnf install -y python3 python3-pip python3-devel gcc gcc-c++
    elif command -v pacman &> /dev/null; then
        sudo pacman -S --noconfirm python python-pip base-devel
    else
        echo "[ERROR] Unknown package manager. Install Python 3.10+ manually."
        exit 1
    fi

    echo ""
    echo "[OK] System dependencies installed!"
    echo "Now run: ./start.sh"
    exit 0
fi

# ==================== CHECK PYTHON ====================
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python3 not found!"
    echo "Run: ./start.sh --setup"
    exit 1
fi
echo "[OK] Python3 detected"

# ==================== CHECK GPU ====================
echo ""
if command -v nvidia-smi &> /dev/null; then
    nvidia-smi --query-gpu=name,memory.total --format=csv,noheader
    echo "[OK] NVIDIA GPU detected"
    export GPU_LAYERS=-1
else
    echo "[ERROR] No NVIDIA GPU detected - this requires a GPU!"
    exit 1
fi

# ==================== CREATE/ACTIVATE VENV ====================
echo ""
if [[ ! -d "venv" ]]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi
source venv/bin/activate

# ==================== CLEANUP MODE ====================
if [[ "$ACTION" == "--cleanup" ]]; then
    echo ""
    echo "[CLEANUP] Freeing disk space..."

    pip uninstall torch torchvision torchaudio llama-cpp-python -y 2>/dev/null || true
    pip cache purge

    if [[ -d "$HOME/.cache/torch" ]]; then
        rm -rf "$HOME/.cache/torch"
        echo "Cleared torch cache"
    fi

    if [[ -d "$HOME/.cache/huggingface" ]]; then
        echo "HuggingFace cache found. Delete? (y/n)"
        read -r confirm
        if [[ "$confirm" == "y" ]]; then
            rm -rf "$HOME/.cache/huggingface"
            echo "Cleared HuggingFace cache"
        fi
    fi

    echo ""
    echo "========================================================"
    echo "  CLEANUP COMPLETE - Run: ./start.sh to reinstall"
    echo "========================================================"
    exit 0
fi

# ==================== FIX GPU MODE ====================
if [[ "$ACTION" == "--fix-gpu" ]]; then
    echo ""
    echo "========================================================"
    echo "  FIXING PYTORCH CUDA (Image Generation GPU)"
    echo "========================================================"
    echo ""

    pip uninstall torch torchvision torchaudio -y
    pip install torch --index-url https://download.pytorch.org/whl/cu124

    echo ""
    python3 -c "import torch; print(f'CUDA: {torch.cuda.is_available()}'); print(f'Device: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else \"N/A\"}')"

    echo ""
    echo "PyTorch CUDA fix complete! Now run: ./start.sh"
    exit 0
fi

# ==================== FIX LLM MODE ====================
if [[ "$ACTION" == "--fix-llm" ]]; then
    echo ""
    echo "========================================================"
    echo "  FIXING LLAMA-CPP-PYTHON CUDA (Text Generation GPU)"
    echo "========================================================"
    echo ""

    pip uninstall llama-cpp-python -y 2>/dev/null || true

    # Install pre-built CUDA 12.1 wheel (compatible with newer CUDA)
    pip install llama-cpp-python --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cu121 --prefer-binary --force-reinstall --no-cache-dir || {
        echo "[ERROR] Failed to install llama-cpp-python"
        exit 1
    }

    echo ""
    python3 -c "from llama_cpp import Llama; print('[OK] llama-cpp-python installed!')"

    echo ""
    echo "LLM CUDA fix complete! Now run: ./start.sh"
    exit 0
fi

# ==================== INSTALL DEPENDENCIES ====================
echo ""
echo "========================================================"
echo "  INSTALLING DEPENDENCIES (CUDA)"
echo "========================================================"
echo ""

pip install --upgrade pip --quiet

echo "Installing Flask..."
pip install flask flask-cors --quiet

echo "Installing PyTorch with CUDA..."
pip install torch --index-url https://download.pytorch.org/whl/cu124 --quiet

echo "Installing diffusers (image generation)..."
pip install diffusers transformers accelerate --quiet

echo "Installing llama-cpp-python with CUDA support..."
pip install llama-cpp-python --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cu121 --prefer-binary --no-cache-dir --quiet || {
    echo "[ERROR] Failed to install llama-cpp-python"
    exit 1
}

# Create directories
mkdir -p models/image data

# ==================== CHECK/DOWNLOAD MODELS ====================
echo ""
echo "========================================================"
echo "  CHECKING/DOWNLOADING MODELS"
echo "========================================================"

python3 src/download_models.py

# ==================== START SERVER ====================
echo ""
echo "========================================================"
echo "  STARTING SERVER"
echo "  http://localhost:8080"
echo "  Press Ctrl+C to stop"
echo "========================================================"
echo ""

export HOST=0.0.0.0
export PORT=8080

python3 src/server.py
